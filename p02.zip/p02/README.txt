Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 02
File Name: README.txt

1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
I found that making the sum and carry of the Halfadder to be somewhat interesting after determining what the actual logic was from a truth table in our Computer Architecture textbook.  sum = xor and carry = and. I also found the Fulladder to be somewhat interesting when I found out that it could be created from two half-adders and an or operator for the carry bit.  I found that the Add16 to be fairly simple after creating a few examples on paper of adding two 16 bit integers so that I could adequately label my sum and carry bits; however, it was a little difficult learning to use the Halfadder for the intial 0 location.  The Inc16 was really simple after having completed the Add16.

2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
The ALU was pretty much a major pain.  Specifically, the Negative(ng) and Zero(zr) output bits.  This was the first project where I actually had to use comments in order to keep track of the various sections which I was implementing in my head.  Therefore, that is the reason for the additional heading comments.  I was not sure if this was alright or not to do? 

3. Estimate how long you worked on the project.
-----------------------------------------------
Approximately one hour for reading.
Approximately three hours for the Halfadder, Fulladder, Add16, and Inc16.
Approximately eight hours for the ALU, README, and submission of the assignment itself.