Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 09
File Name: README.txt

1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
The .jack language utilized was very similar to the Java programming language and since I programmed mostly in the Java programming language over the Summer during my internship with Shelter Insurance, it helped complete this project with a bit of ease.

2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
Figuring out the game programming structure again was somewhat of a nuisciance for me since I have not done much game programming over the years here at Columbia College this lead to most of the issues for me.  However, programming the Breakout game in ciss145 Python Programming class provided some helpful and useful insight in relearning the game programming methodology.

3. Estimate how long you worked on the project.
-----------------------------------------------
Reading Textbook = 2 hours.
Requirement and Design = 3 hours.

Main.jack = 1 hour.
SnakeGame.jack = 8 hours.
Snake.jack = 8 hours.
Square.jack = 4 hours.
Circle.jack = 3 hours.
-----------------------------
Coding and Testing = 24 hours

4. Describe any instructions for using the program.
---------------------------------------------------
1) Run the JackCompiler on the directory which contains the .jack files within.  This will convert the .jack files into .vm files.
2) Next, run the VMEmulator on the directory which now contains both the .jack and .vm files within.  This will allow the .vm files to be ran to simulate game play. Note: remember to turn off animate to the "No Animation" Mode.
3) Game play involves the following key commands:
	▲ --> Moves the Snake in the Northern region of the screen --> -y.
	► --> Moves the Snake in the Eastern region of the screen --> +x.
	▼ --> Moves the Snake in the Southern region of the screen ->> +y.
	◄ --> Moves the Snake in the Western region of the screen ->> -x.
	○ --> Snake food which the snake must pick up to grow.
	■ --> Snake head, body, or tail elements which grows with food pick-ups.


