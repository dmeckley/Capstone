# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 07
# File Name: VMtranslator.py

import sys
import Parser
import CodeWriter

class VMtranslator(object):

    # VMtranslator Global Data Attributes:

    def __init__(self, inputFile):

        # Setup/Initialization of the VMtranslator object:

        # VMtranslator Object Data Attribute Initialization:
        self.inputFile = inputFile
        self.outputFile = (inputFile.replace('.vm', '.asm') 
            if inputFile.endswith('.vm') 
            else inputFile + '.asm')

    def execution(self):

        # Execution of the VMtranslator object:

        # Performs the execution of the program.
        parser = Parser.Parser(self.inputFile)
        codeWriter = CodeWriter.CodeWriter(self.outputFile)
        codeWriter.setFileName(self.outputFile[:-3])
        while parser.hasMoreCommands():
            parser.advance()
            commandType = parser.commandType()
            if commandType == 'C_ARITHMETIC':
               codeWriter.writeArithmetic(parser.command)
            elif commandType == 'C_PUSH' or commandType == 'C_POP':
                if 'pop' in parser.command:
                    command = 'pop'
                else:
                    command = 'push'
                segment = parser.arg1()
                index = parser.arg2()
                codeWriter.WritePushPop(command, segment, index)      
        codeWriter.Close()
        

def main():
    
    # Main program execution:
    # Accepts commandline arguments from the user
    # and catches an exception if the file does not 
    # exist or the input from the user is invalid.


    # Local Variable Declaration and Initialization.
    inputFile = ""

    # Accept fileName.vm as commandline argument and create an
    # VMtranslator object instance passing in the inputFile.  
    # Call VMtranslator execution() method with object instance
    # to perform proper execution.
    # Handle exceptions if problems occur with file or object 
    # instance creation.
    try:
        inputFile = sys.argv[1]
        vm = VMtranslator(inputFile)
        vm.execution()
    except (IOError, IndexError):
        print
        print("==================================")
        print("    Invalid Commandline Input!    ")
        print("     Format input as follows:     ") 
        print("python VMtranslator.py fileName.vm") 
        print("==================================")
        print


# Call the main function:
main()