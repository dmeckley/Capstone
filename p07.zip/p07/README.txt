Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 07
File Name: README.txt

1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
Doing this project allowed me the oppurtunity to clean-up my Parser.py source file while adding new functions to it.  I cleaned up the constructor, the hasMoreCommands(), the advance(), and the commandType() from Project # 6 while adding the arg1() and arg2().  I also utilized my Assembler.py from project # 6 to make my VMtranslator.py for project # 7; however, many changes were made to clean it up.  

2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
CodeWriter.py all the way through was a pain, especially writeArithmetic() and WritePushPop(). The understanding of how everything was suppose to work in the very limited time to actually work on the project was pretty time consuming, difficult, and frustrating.  

3. Estimate how long you worked on the project.
-----------------------------------------------
VMtranslator.py took an approximately 5 hours.
Parser.py took an approximately 3 hours.
CodeWriter.py took an approximately 15 hours.
README.txt took an approximately 1 hour.
Reading the textbook took approximately 2 hours.
Requirements and Design took approximately 3 hours.
Altogether, Coding and Testing took an approximately 30 hours.

4. Describe how to build/compile your translator code.
------------------------------------------------------
python VMtranslator.py fileName.vm is the compilation process on the command line.  However, I did not actually design mine to take directories in so for right now, all the .vm files have to be in the same directory as the VMtranslator.py, Parser.py, and CodeWriter.py.  I suspect that I will try to implement directories in Project # 8, if time permits?  

5. Instructions describing how to use your translator.
------------------------------------------------------
1. python VMtranslator.py fileName.vm - will create the fileName.asm. 
2. fileName.asm will appear in the same directory as the VMtranslator.py, Parser.py, and CodeWriter.py source files.
3. Copy the fileName.tst and fileName.cmp to the same directory which holds the the VMtranslator.py, Parser.py, CodeWriter.py, and fileName.vm. These can be found under the MemoryAccess and StackArithmetic directories.
4. Open up the CPU Emulator.
5. Goto Load ROM and select fileName.asm
6. Goto Load Script and select fileName.tst.
7. Press the >> button and watch it execute. 

6. Comments on any part(s) of the translator project that doesn't work and attempts to solve it.
------------------------------------------------------------------------------------------------
It all works I do believe but it took a long time to get it all to work.  The PointerTest.asm was not passing the PointerTest.tst so I had to make some changes to the way which I was writing my temp and pointer segments to the .asm file.  It looks kind of hidious, to say the least, but it worked eventually.  