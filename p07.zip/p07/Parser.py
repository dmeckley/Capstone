# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 07
# File Name: Parser.py

class Parser(object):

    # Parser Global Data Attributes:

    def __init__(self, inputFile): 													
        
        # Setup/Initialization of the Parser object:

        # Accepts input file stream and reads the line of statements in.
        with open(inputFile, 'r') as file:
            self.inputFileLines = file.readlines()

        # Parser Object Data Attribute Initialization:
        self.currentLineIndex = 0

    def hasMoreCommands(self): 														
       
        # Returns true if the input has more commands to process:
        # returns boolean.

        # returns boolean true as long as their are more lines to process;
        # otherwise, it returns false indicating that we have reached the end 
        # of statements to process.
        return (True if (self.currentLineIndex + 1) < len(self.inputFileLines) 
            else False)

    def advance(self): 																

        # Reads the next command from the input and makes it the current 
        # command.
        # Should only be called if hasMoreCommands() is true.
        # Initially there is no commands.

        # Reads in the statements and strips away comments and whitespaces
        # while advancing to the next line when more statements need processed.
        self.currentLineIndex += 1
        line = self.inputFileLines[self.currentLineIndex]
        if "//" in line:
            location = line.find("//")
            line = line[:location] + '\n'    
        if line.startswith("//"):
            line = ''
        if line == '\n':
            self.advance()
        else:
            self.command = line.strip()

    def commandType(self):															
        
        # Returns the type of the current vm command:
        # C_ARITHMETIC is returned for all the arithmetic commands.
        # returns C_ARITHMETIC, C_PUSH, C_POP, C_LABEL, C_GOTO, C_IF, 
        # C_FUNCTION, C_RETURN, C_CALL.

        # Splits the commandType out of the overall statement and 
        # returns the proper commandType 
        # for the command condition provided.
        command = self.command.split(' ', 1)[0]
        if (command == 'add' or command == 'sub' 
            or command =='neg' or command == 'eq' 
            or command =='gt' or command =='lt' 
            or command =='and' or command == 'or' 
            or command =='not'):
            return 'C_ARITHMETIC'
        if command == 'push':
            return 'C_PUSH'
        if command == 'pop':
            return 'C_POP'
        # if command == 'label':
        #     return 'C_LABEL'
        # if command == 'goto':
        #     return 'C_GOTO'
        # if 'if' in command:
        #     return 'C_IF'
        # if command == 'function':
        #     return 'C_FUNCTION'
        # if command == 'return':
        #     return 'C_RETURN'
        # if command == 'call':
        #     return 'C_CALL'

    def arg1(self):

		# Returns the 1st argument of the current command.
		# In the case of C_ARITHMETIC, the command itself is returned ex:
		# add, sub, etc.
		# Should not be called if the current command is C_RETURN.
		# returns string.

        # If commandType is arithmetic, logical, or comparable, 
        # then return only the arithmetic command as segment; 
        # otherwise, return the actual representation of the segment. 
        segment = self.command.split()
        if self.commandType() == 'C_ARITHMETIC':
            return segment[0]
        else:
            return segment[1]

    def arg2(self):
       
		# Returns the 2nd argument of the current command.
		# Called only when the current commmand is:
		# C_PUSH, C_POP, C_FUNCTION, or C_CALL.
     	# returns int.

        # Return the numerical index value from the statement.
     	index = self.command.split()
        return index[2]

        
        

   