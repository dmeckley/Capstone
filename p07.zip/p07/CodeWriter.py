# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 07
# File Name: CodeWriter.py

class CodeWriter(object):

    # CodeWriter Global Data Attributes:

    
	def __init__(self, outputFile):																

        # Initialization of the CodeWriter object:
        # Accepts output file stream:

        # Opens the outputFile stream for writing to.
		self.outputFile = open(outputFile, 'w')

		# Writes the initial stack pointer memory location for program initialization.
		self.outputFile.write('@256' + '\n')
		self.outputFile.write('D=A' + '\n')
		self.outputFile.write('@SP' + '\n')
		self.outputFile.write('M=D' + '\n')

		# CodeWriter Object Data Attribute Initialization:
		self.labelIndexer = 0
    	
	def setFileName(self, fileName):															

        # Informs the code writer that the translation of a new VM file is started.
        # Accepts fileName string.

        # Creates a fileName without the extension for static global identifier use:
        # Formatted as outputFileName.X where X represents the number for the static 
        # memory.
		self.fileName = fileName 

	def writeArithmetic(self, command):

    	# Writes the assembly code that is the translation of the given arithmetic 
    	# command.
    	# Accepts command string.

    	# Writes the converted .asm code for the Arithmetic Logic Unit conditions  
    	# including the comparison conditions.

		# Binary Operations:
		if command == 'add' or command == 'sub' or command == 'and' or command == 'or': 

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')

			# Pop top of stack to D:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('D=M' + '\n')

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')

			# Pop top of stack to A:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('A=M' + '\n')

			# Arithmetic/Logic Operation Creation:
			if command == 'add':
				self.outputFile.write('D=A+D' + '\n')
			if command == 'sub':
				self.outputFile.write('D=A-D' + '\n')
			if command == 'and':
				self.outputFile.write('D=A&D' + '\n')
			if command == 'or':
				self.outputFile.write('D=A|D' + '\n')

			# Push D onto stack:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=D' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n') 

        # Unary Operations:
		if command == 'neg' or command == 'not': 

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')

			# Pop top of stack to D:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('D=M' + '\n')

			# Arithmetic/Logic Operation Creation:
			if command == 'neg':
				self.outputFile.write('D=-D' + '\n')
			if command == 'not':
				self.outputFile.write('D=!D' + '\n')

			# Push D onto stack:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=D' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n') 

		# Comparison Operations:
		if command == 'eq' or command == 'gt' or command == 'lt':

			# Conditional and Unconditional Label Initialization:
			condLabel = 'COND_LABEL' + str(self.labelIndexer)
			unCondLabel = 'JUMP_LABEL' + str(self.labelIndexer)

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')

			# Pop top of stack to D:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('D=M' + '\n')

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')

			# Pop top of stack to A:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('A=M' + '\n')

			# Conditional Label Pointer Creation:
			self.outputFile.write('D=A-D' + '\n')
			self.outputFile.write('@' + condLabel + '\n') 

			# Comparison Operation Creation:
			if command == 'eq':
				self.outputFile.write('D;' + 'JEQ' + '\n')  
			if command == 'gt':  
				self.outputFile.write('D;' + 'JGT' + '\n')  
			if command == 'lt':
				self.outputFile.write('D;' + 'JLT' + '\n') 
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=0' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n')  

			# Unconditional Label Pointer Creation:
			self.outputFile.write('@' + unCondLabel + '\n')
			# Jump Operation Creation:
			self.outputFile.write('0;JMP' + '\n') 
			# Conditional Label Creation:    
			self.outputFile.write('(' + condLabel + ')' + '\n')
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=-1' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n')    

			# Unconditional Label Creation: 
			self.outputFile.write('(' + unCondLabel + ')' + '\n')

			# Increment Label Identifier Index:
			self.labelIndexer += 1

	def WritePushPop(self, command, segment, index):

        # Writes the assembly code that is the translation of the given command,
    	# where command is either C_PUSH or C_POP.
    	# Accepts command C_PUSH or C_POP, segement string, index int.

    	# Writes the converted .asm code for the Memory Access conditions.

    	# Push Command Operations:
		if command == 'push':

			# Argument Segment:
			if segment == 'argument':
				self.outputFile.write('@' + 'ARG' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('A=D+A' + '\n')
				self.outputFile.write('D=M' + '\n')

			# Local Segment:
			if segment == 'local':
				self.outputFile.write('@' + 'LCL' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('A=D+A' + '\n')
				self.outputFile.write('D=M' + '\n')

			# Static Segment:
			if segment == 'static':
				self.outputFile.write('@' + self.fileName + index + '\n')
				self.outputFile.write('D=M' + '\n') 

			# Constant Segment:
			if segment == 'constant':
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('D=A' + '\n')

			# This Segment:
			if segment == 'this':
				self.outputFile.write('@' + 'THIS' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('A=D+A' + '\n')
				self.outputFile.write('D=M' + '\n')

			# That Segment:
			if segment == 'that':
				self.outputFile.write('@' + 'THAT' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('A=D+A' + '\n')
				self.outputFile.write('D=M' + '\n')

			# Pointer Segment:
			if segment == 'pointer':
				self.outputFile.write('@%d\n' %(3 + int(index)))
				self.outputFile.write('D=M' + '\n')

			# Temp Segment:
			if segment == 'temp':
				self.outputFile.write('@%d\n' %(5 + int(index)))
				self.outputFile.write('D=M' + '\n')

			# Push D onto stack:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=D' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n')  

		# Pop Command Operations:
		if command == 'pop':

			# Argument Segment:
			if segment == 'argument':
				self.outputFile.write('@' + 'ARG' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('D=D+A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# Local Segment:
			if segment == 'local':
				self.outputFile.write('@' + 'LCL' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('D=D+A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# Static Segment:
			if segment == 'static':
				self.outputFile.write('@' + self.fileName + index + '\n')
				self.outputFile.write('D=A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# This Segment:
			if segment == 'this':
				self.outputFile.write('@' + 'THIS' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('D=D+A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# That Segment:
			if segment == 'that':
				self.outputFile.write('@' + 'THAT' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('D=D+A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# Pointer Segment:		
			if segment == 'pointer':
				self.outputFile.write('@%d\n' %(3 + int(index)))
				self.outputFile.write('D=A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# Temp Segment:
			if segment == 'temp':
				self.outputFile.write('@%d\n' %(5 + int(index)))
				self.outputFile.write('D=A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')
			
			# Pop top of stack to D:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('D=M' + '\n')

			self.outputFile.write('@R13' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=D' + '\n')

	def Close(self):
        
        # Closes the output file.

        # Creates infinite loop at the end of .asm source file:
		endLabel = 'END' 
		self.outputFile.write('(' + endLabel + ')' + '\n')
		self.outputFile.write('@' + endLabel + '\n')
		self.outputFile.write('0;JMP' + '\n') 

		# Closes the outputFile:
		self.outputFile.close
