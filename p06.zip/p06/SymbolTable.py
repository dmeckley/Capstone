# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 06
# File Name:Symbol.py

class SymbolTable(object):

    # SymbolTable Data Attributes:
    symbolTable =   {
                        'SP': 0, 
                        'LCL':1, 
                        'ARG':2, 
                        'THIS':3, 
                        'THAT':4,
                        'R0':0, 
                        'R1':1, 
                        'R2':2, 
                        'R3':3, 
                        'R4':4, 
                        'R5':5, 
                        'R6':6, 
                        'R7':7,
                        'R8':8, 
                        'R9':9, 
                        'R10':10, 
                        'R11':11, 
                        'R12':12, 
                        'R13':13, 
                        'R14':14,
                        'R15':15, 
                        'SCREEN':0x4000, 
                        'KBD':0x600
                    }

    def __init__(self):

        # Setup/Initialization of the SymbolTable object:
        pass
        
    def addEntry(self, symbol, address):
       
        # Addition of a key-value pair to symbols table:
        self.symbolTable[symbol] = address

    def contains(self, symbol):
       
        # Return the symbol from the symbols table for a key-value pair: 
        symbol = symbol in self.symbolTable
        return symbol

    def GetAddress(self, symbol):
        
        # Return the address for a symbol from the symbols table for a key-value pair: 
        address = self.symbolTable[symbol]
        return address