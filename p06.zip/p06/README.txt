Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 06
File Name: README.txt

1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
This project was a nice refresher to the Python programming language since I had not really programmed in Python since my Freshman year here.  It also allowed me to see why everyone who took this course before me said it was better to do it in the Python programming language.  The slicing operation on the strings was essential to doing this project.  It also gave me a chance to learn a little more about Regular Expressions in the Python programming language.  I had learned a little about Regular Expressions and pattern matching in the Java programming language over the Summer; therefore, I tried to use Regular Expressions to begin with on this project; however, I still don't really feel like I know them well enought to be efficient with them or to actually have a real good understanding of them.  

2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
The Parser.py was the hardest out of all of the source codes to complete for me.  I bet I spent about a day or day and a half on that part alone.  I tried it with Regular Expressions and finally decided to stick with string slicing for proper operations.  The Assembler.py was also a pain too try to figure out but it got easier as I got the other source files developed; however, understanding how to go about the two pass structure was hard to figure out how to implement.   

3. Estimate how long you worked on the project.
-----------------------------------------------
Reading: 1 - 2 hour(s)
Requirement, Analyze, and Design: 1 hour
Assembly.py: 5 hours
Parser.py: 12 hours
Code.py: 2 hours
SymbolTable.py: 2 hours
README.txt: 30 minutes
Testing: 30 minutes

4. Instruction on how to build/compile the assembler code.
----------------------------------------------------------
I built mine using Python v2.7 and I did it on the Windows 7 operating system with the Powershell so building it is fairly straighforward:  Put all the source code in the same directory, then change directories until the commandline prompt is at that directory, then enter "python Assembler.py fileName.asm" where fileName can be any of the seven practice files provided to us: Add.asm, Max.asm, MaxL.asm, Rect.asm, RectL.asm, Pong.asm, or PongL.asm. 

5. Instructions describing how to use the assember.
---------------------------------------------------
I built mine using Python v2.7 and I did it on the Windows 7 operating system with the Powershell so building it is fairly straighforward:  Put all the source code in the same directory, then change directories until the commandline prompt is at that directory, then enter "python Assembler.py fileName.asm" where fileName can be any of the seven practice files provided to us: Add.asm, Max.asm, MaxL.asm, Rect.asm, RectL.asm, Pong.asm, or PongL.asm. 

6. Comments on any part of the assembler project that isn't working properly.
-----------------------------------------------------------------------------
No comments here because everything seems to work from the testing that I put forth.

References:
-----------
https://docs.python.org/2/library/index.html
https://docs.python.org/2/library/re.html