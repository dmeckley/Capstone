# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 06
# File Name: Parser.py

import re

class Parser(object):

    # Parser Data Attributes:
    A_COMMAND = 0
    C_COMMAND = 1
    L_COMMAND = 2

    rePattern = r'//.*$'
    reObject = re.compile(rePattern)

    def __init__(self, inputFile):
        
        # Setup/Initialization of the Parser object:
        with open(inputFile, 'r') as file:
            self.fileLines = file.readlines()
        self.command = ''
        self.currentLineIndex = 0

    def hasMoreCommands(self):
       
        # Returns true if the input has more commands to process:
        if (self.currentLineIndex + 1) < len(self.fileLines):
            return True
        else:
            return False

    def advance(self): # *****still needs to get in operation properly to work*****

        # Accepts the input of the next command:
        self.currentLineIndex += 1
        line = self.fileLines[self.currentLineIndex]
        # line = self.reObject.sub('', line)
        line = re.sub(r'//.*$', '', line) 
        print 'line# = ' + str(self.currentLineIndex) + ' line = ' + line
        if line == '\n':
            self.advance()
        else:
            self.command = line.strip()

    def commandType(self):
        
        # Returns the current command type:
        if re.match(r'^@.*', self.command):
            return Parser.A_COMMAND
        elif re.match(r'^\(.*', self.command):
            return Parser.L_COMMAND
        else:
            return Parser.C_COMMAND

    def symbol(self):

        # Returns the symbol of the current command:
        matching = re.match(r'^[@\(](.*?)\)?$', self.command)
        symbol = matching.group(1)
        # print 'symbol = ' + symbol
        return symbol
    
    def dest(self):
       
        # Returns the dest mnemonic for the current C_COMMAND:
        matching = re.match(r'^(.*?)=.*$', self.command)
        if not matching:
            dest = ''
        else:
            dest = matching.group(1)
        # print 'dest = ' + dest
        return dest

    def comp(self):
        
        # Returns the comp mnemonic for the current C_COMMAND:
        comp = re.sub(r'^.*?=', '', self.command) 
        comp = re.sub(r';\w+$', '', comp) 
        if not comp:
            print("No comp!")
            print(self.command)
        # print 'comp.strip() = ' + comp.strip()
        return comp.strip()

    def jump(self):
       
        # Returns the jump mnemonic for the current C_COMMAND:
        matching = re.match(r'^.*;(\w+)$', self.command)
        if not matching:
            jump = ''
        else:
            jump = matching.group(1)
        # print 'jump = ' + jump
        return jump

        