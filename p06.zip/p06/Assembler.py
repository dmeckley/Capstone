# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 06
# File Name: Assembler.py

import sys
import Parser
import Code
import SymbolTable

class Assembler(object):

    def __init__(self, inputFile):
      
        # Setup/Initialization of the Assembler object:
        self.inputFile = inputFile
        self.outputFile = (inputFile.replace('.asm', '.hack') 
            if inputFile.endswith('.asm') 
            else inputFile + '.hack')
        self.symbolTable = SymbolTable.SymbolTable()
        self.symbolAddress = 16 

    def firstPass(self):
        
        # Creation of the symbols table:
        parser = Parser.Parser(self.inputFile)
        currentAddress = 0
        while parser.hasMoreCommands():
            parser.advance()
            if (parser.commandType() == parser.A_COMMAND 
                or parser.commandType() == parser.C_COMMAND):
                currentAddress += 1
            if parser.commandType() == parser.L_COMMAND:
                self.symbolTable.addEntry(parser.symbol(), currentAddress)

    def secondPass(self):
       
        # Creation of the binary outputFile from parsing the inputFile: 
        parser = Parser.Parser(self.inputFile)
        outFile = open(self.outputFile, 'w')
        code = Code.Code()
        while(parser.hasMoreCommands()):
            parser.advance()
            if parser.commandType() == parser.A_COMMAND:
                outFile.write(code.aInst(self.getAddress(parser.symbol())) + '\n')
            if parser.commandType() == parser.C_COMMAND:
                outFile.write(code.cInst(parser.comp(), parser.dest(), parser.jump()) + '\n')
        outFile.close()

    def getAddress(self, symbol):
        
        # Return's the address for the provided symbol:
        if symbol.isdigit():
            return symbol
        else:
            if not self.symbolTable.contains(symbol):
                self.symbolTable.addEntry(symbol, self.symbolAddress)
                self.symbolAddress += 1
            address = self.symbolTable.GetAddress(symbol)
            return address

def main():
    
    # Main program execution:
    # Accepts commandline arguments from the user
    # and catches an exception if the file does not 
    # exist or the input from the user is invalid.
    inputFile = ""
    try:
        inputFile = sys.argv[1]
        assembly = Assembler(inputFile)
        assembly.firstPass()
        assembly.secondPass()
    except (IOError, IndexError):
        print
        print("================================")
        print("   Invalid Commandline Input!   ")
        print("    Format input as follows:    ") 
        print("python Assembler.py fileName.asm") 
        print("================================")
        print

# Calls the main function:
main()