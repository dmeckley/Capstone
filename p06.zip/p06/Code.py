# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 06
# File Name: Code.py

class Code(object):

    # Code Data Attributes:
    destCodes = [
                    '', 
                    'M', 
                    'D', 
                    'MD', 
                    'A', 
                    'AM', 
                    'AD', 
                    'AMD'
                ]

    compCodes = {
                    '0':'0101010', 
                    '1':'0111111', 
                    '-1':'0111010', 
                    'D':'0001100',
                    'A':'0110000', 
                    '!D':'0001101', 
                    '!A':'0110001', 
                    '-D':'0001111',
                    '-A':'0110011', 
                    'D+1':'0011111',
                    'A+1':'0110111',
                    'D-1':'0001110',
                    'A-1':'0110010',
                    'D+A':'0000010',
                    'D-A':'0010011',
                    'A-D':'0000111',
                    'D&A':'0000000',
                    'D|A':'0010101',
                    '':'xxxxxxx',
                    'M':'1110000', 
                    '!M':'1110001', 
                    '-M':'1110011', 
                    'M+1':'1110111',
                    'M-1':'1110010',
                    'D+M':'1000010',
                    'D-M':'1010011',
                    'M-D':'1000111',
                    'D&M':'1000000', 
                    'D|M':'1010101' 
                }

    jumpCodes = [
                    '', 
                    'JGT', 
                    'JEQ', 
                    'JGE', 
                    'JLT', 
                    'JNE', 
                    'JLE', 
                    'JMP'
                ]

    def __init__(self):

        # Setup/Initialization of the Code object:
        pass

    def dest(self, mnemonic):
        
        # Returns the binary code for the dest mnemonic for C-instructions:
        dest = bin(int(self.destCodes.index(mnemonic)))[2:].zfill(3) 
        return dest

    def comp(self, mnemonic):

        # Returns the binary code for the comp mnemonic for C-instructions:
        comp = self.compCodes[mnemonic]
        return comp

    def jump(self, mnemonic):

        # Returns the binary code for the jump mnemonic for C-instructions:
        jump = bin(int(self.jumpCodes.index(mnemonic)))[2:].zfill(3)
        return jump

    def aInst(self, address):

        # Returns the binary code for A-instructions:
        aInst = '0' + bin(int(address))[2:].zfill(15)
        return aInst 

    def cInst(self, comp, dest, jump):
        
        # Returns the binary code for C-instructions:
        cInst = '111' + self.comp(comp) + self.dest(dest) + self.jump(jump)
        return  cInst

    