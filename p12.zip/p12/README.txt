Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 12
File: README.txt



1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
Building a complete but basic operating system like this was pretty cool especially since they do not offer the Operating System course until the next upcoming semester so it was nice to be able to learn the basics before taking on that course during the next semester, if I do decide to enroll in it.  Either way, it was nice learning some Operating System concepts and being able to create an basic operating system in the .jack programming language so that way when I graduate, I can at least have had some exposure to it.  Also, I found the .jack programming language to be fairly straight forward to create the operating system within since it is very similar the the .java programming language which I am probably the most comfortable with at this given moment in time.  I found the Array.jack, Keyboard.jack, and Sys.jack to be the easiest classes to implement in the operating system.


2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
The readChar function in the Keyboard.jack file was difficult to implement due to the keyboard pressing and releasing.  This took me some time to figure out how to make it work properly.  The multiply and divide function in the Math.jack file was also was difficult to code because of the bit shifting required for the int x and int y.  For the Memory.jack source file, the only real issue I faced here was with deciding the implementation of the alloc function.  There was a lot of data structure programming that I had to remember to implement this function.  Lets face it, as far as I am concerned.  The Output.jack was the one source file I spent the most time on trying to figure out how it all works.  I never knew there was so much data to the output portion of an input/output system.  The String.jack was another source code that was difficult to implement for the operating system.  I found the appendChar, intValue, and setInt to be the most difficult functions to figure out how to code for the String.jack class.   


3. Estimate how long you worked on the project.
-----------------------------------------------
Reading:   					2 hour(s)                  
Requirements and Design: 	3 hour(s)   
Array.jack				   .5 hour(s)
Keyboard.jack				2 hour(s)
Math.jack					5 hour(s)
Memory.jack					5 hour(s)
Output.jack				   13 hour(s)
Screen.jack				  8.5 hour(s)
String.jack					7 hour(s)
Sys.jack  					2 hour(s)
README.txt:					1 hour(s) 							 
--------------------------------------
Coding and Testing:		   43 hour(s) 	
======================================
Total:					   49 hour(s)					


4. Comments on any part of the compiler project which doesn't work properly and attempts to solve it.
-----------------------------------------------------------------------------------------------------
1) When you test the Math file, you need to increase the number of steps in
the 'MathTest.tst' file.

The following segment:
repeat 1000000 {
  vmstep;
}

should be changed to:
repeat 2000000 {
  vmstep;
}

This is because my solution takes more steps than the built-in and it's
unable to finish in 1 million steps.

2) When testing any program you can add any of my .jack files to
substitute part of the operating system, however the files
'Keyboard.jack' and 'Output.jack' must always go together. This is because 
the built-in 'Keyboard.jack' and 'Output.jack' files slightly deviate from 
their specifications and are not compatible with mine. Therefore you must 
either use both of the built-ins, or both of mine, but don't mix & match them.

3) You will notice that my implementations is slower than the
built-ins. If you add all 8 of my .jack files to any project, it will be very slow; 
however, if you add only a few, then it will be less slow. This is because I didn't 
optimize them, my focus was on doing them correctly and completing the assignemnet for
project # 12.  I also wanted to keep the code as simple and clear as possible for the 
user(s).
