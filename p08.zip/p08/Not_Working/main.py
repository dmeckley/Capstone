# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 08
# File Name: main.py

from sys import *
from VMtranslator import *

if __name__ == '__main__':
  
    # Main program execution:
    # Accepts commandline arguments from the user and 
    # creates a VMtranslator object passing in the file
    # or directory provided by the user.

    # Accept fileName.vm or directoryPath as commandline argument 
    # and create an VMtranslator object instance passing in the inputFile.  

    inputFile = argv[1]
    vm = VMtranslator(inputFile)
   
