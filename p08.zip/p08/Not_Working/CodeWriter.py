# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 08
# File Name: CodeWriter.py

class CodeWriter(object):

    # CodeWriter Data Attributes:

	def __init__(self, outputFile):

        # Initialization of the CodeWriter object:
        # Accepts output file stream:

        # Opens the outputFile stream for writing to.
		self.outputFile = open(outputFile, 'w')

		# CodeWriter Object Data Attribute Initialization:
		self.labelIndexer = 0

		# Calls the writeInit() method to write the initial stack pointer memory 
		# location for program initialization.
		self.writeInit()

	def setFileName(self, fileName):

        # Informs the code writer that the translation of a new VM file is started.
        # Accepts fileName string.

        # Creates a fileName without the extension for static global identifier use:
        # Formatted as outputFileName.X where X represents the number for the static 
        # memory.
		self.fileName = fileName

	def writeInit(self):

		# Writes assembly code that effects the VM initialization or bootstrap code.
		# This code must be placed at the beginning of the output file.

		# Writes the initial stack pointer memory location for program initialization
		# and performs bootstrap code.
		self.outputFile.write('@256' + '\n')
		self.outputFile.write('D=A' + '\n')
		self.outputFile.write('@SP' + '\n')
		self.outputFile.write('M=D' + '\n')
		self.writeCall('Sys$init', 0) 
		
	def writeArithmetic(self, command):

    	# Writes the assembly code that is the translation of the given arithmetic
    	# command.
    	# Accepts command string.

    	# Writes the converted .asm code for the Arithmetic Logic Unit conditions
    	# including the comparison conditions.

		# Binary Operations:
		if command == 'add' or command == 'sub' or command == 'and' or command == 'or':

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')

			# Pop top of stack to D:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('D=M' + '\n')

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')

			# Pop top of stack to A:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('A=M' + '\n')

			# Arithmetic/Logic Operation Creation:
			if command == 'add':
				self.outputFile.write('D=A+D' + '\n')
			if command == 'sub':
				self.outputFile.write('D=A-D' + '\n')
			if command == 'and':
				self.outputFile.write('D=A&D' + '\n')
			if command == 'or':
				self.outputFile.write('D=A|D' + '\n')

			# Push D onto stack:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=D' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n')

        # Unary Operations:
		if command == 'neg' or command == 'not':

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')

			# Pop top of stack to D:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('D=M' + '\n')

			# Arithmetic/Logic Operation Creation:
			if command == 'neg':
				self.outputFile.write('D=-D' + '\n')
			if command == 'not':
				self.outputFile.write('D=!D' + '\n')

			# Push D onto stack:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=D' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n')

		# Comparison Operations:
		if command == 'eq' or command == 'gt' or command == 'lt':

			# Conditional and Unconditional Label Initialization:
			condLabel = 'COND_LABEL' + str(self.labelIndexer)
			unCondLabel = 'JUMP_LABEL' + str(self.labelIndexer)

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')

			# Pop top of stack to D:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('D=M' + '\n')

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')

			# Pop top of stack to A:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('A=M' + '\n')

			# Conditional Label Pointer Creation:
			self.outputFile.write('D=A-D' + '\n')
			self.outputFile.write('@' + condLabel + '\n')

			# Comparison Operation Creation:
			if command == 'eq':
				self.outputFile.write('D;' + 'JEQ' + '\n')
			if command == 'gt':
				self.outputFile.write('D;' + 'JGT' + '\n')
			if command == 'lt':
				self.outputFile.write('D;' + 'JLT' + '\n')
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=0' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n')

			# Unconditional Label Pointer Creation:
			self.outputFile.write('@' + unCondLabel + '\n')

			# Jump Operation Creation:
			self.outputFile.write('0;JMP' + '\n')
			
			# Conditional Label Creation:
			self.outputFile.write('(' + condLabel + ')' + '\n')
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=-1' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n')

			# Unconditional Label Creation:
			self.outputFile.write('(' + unCondLabel + ')' + '\n')

			# Increment Label Identifier Index:
			self.labelIndexer += 1

	def WritePushPop(self, command, segment, index):

        # Writes the assembly code that is the translation of the given command,
    	# where command is either C_PUSH or C_POP.
    	# Accepts command C_PUSH or C_POP, segement string, index int.

    	# Writes the converted .asm code for the Memory Access conditions.

    	# Push Command Operations:
		if command == 'push':

			# Argument Segment:
			if segment == 'argument':
				self.outputFile.write('@' + 'ARG' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('A=D+A' + '\n')
				self.outputFile.write('D=M' + '\n')

			# Local Segment:
			if segment == 'local':
				self.outputFile.write('@' + 'LCL' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('A=D+A' + '\n')
				self.outputFile.write('D=M' + '\n')

			# Static Segment:
			if segment == 'static':
				self.outputFile.write('@' + self.fileName + index + '\n')
				self.outputFile.write('D=M' + '\n')

			# Constant Segment:
			if segment == 'constant':
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('D=A' + '\n')

			# This Segment:
			if segment == 'this':
				self.outputFile.write('@' + 'THIS' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('A=D+A' + '\n')
				self.outputFile.write('D=M' + '\n')

			# That Segment:
			if segment == 'that':
				self.outputFile.write('@' + 'THAT' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('A=D+A' + '\n')
				self.outputFile.write('D=M' + '\n')

			# Pointer Segment:
			if segment == 'pointer':
				self.outputFile.write('@%d\n' %(3 + int(index)))
				self.outputFile.write('D=M' + '\n')

			# Temp Segment:
			if segment == 'temp':
				self.outputFile.write('@%d\n' %(5 + int(index)))
				self.outputFile.write('D=M' + '\n')

			# Push D onto stack:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=D' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n')

		# Pop Command Operations:
		if command == 'pop':

			# Argument Segment:
			if segment == 'argument':
				self.outputFile.write('@' + 'ARG' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('D=D+A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# Local Segment:
			if segment == 'local':
				self.outputFile.write('@' + 'LCL' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('D=D+A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# Static Segment:
			if segment == 'static':
				self.outputFile.write('@' + self.fileName + index + '\n')
				self.outputFile.write('D=A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# This Segment:
			if segment == 'this':
				self.outputFile.write('@' + 'THIS' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('D=D+A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# That Segment:
			if segment == 'that':
				self.outputFile.write('@' + 'THAT' + '\n')
				self.outputFile.write('D=M' + '\n')
				self.outputFile.write('@' + index + '\n')
				self.outputFile.write('D=D+A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# Pointer Segment:
			if segment == 'pointer':
				self.outputFile.write('@%d\n' %(3 + int(index)))
				self.outputFile.write('D=A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# Temp Segment:
			if segment == 'temp':
				self.outputFile.write('@%d\n' %(5 + int(index)))
				self.outputFile.write('D=A' + '\n')
				self.outputFile.write('@R13' + '\n')
				self.outputFile.write('M=D' + '\n')

			# Decrement StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M-1' + '\n')

			# Pop top of stack to D:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('D=M' + '\n')

			self.outputFile.write('@R13' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=D' + '\n')

	def writeLabel(self, label):												

		# Writes assembly code that effects the label command.
		# Accepts label(string) argument.

		# Write the (label) identifier to the .asm file 
		# which is provided to the function.
		self.outputFile.write('(' + label + ')' + '\n')

	def writeGoto(self, label):													

		# Writes assembly code that effects the goto command.
		# Accepts label(string) argument.

		# Write the @label identifier to the .asm file  
		# which is provided to the function as well as providing 
		# an unconditional jump instruction to the .asm file.
		self.outputFile.write('@' + label + '\n')
		self.outputFile.write('0;JMP' + '\n')

	def writeIf(self, label):													

		# Writes assembly code that effects the if-goto command.
		# Accepts label(string) argument.

		# Decrement StackPointer:
		self.outputFile.write('@SP' + '\n')
		self.outputFile.write('M=M-1' + '\n')

		# Pop top of stack to D:
		self.outputFile.write('@SP' + '\n')
		self.outputFile.write('A=M' + '\n')
		self.outputFile.write('D=M' + '\n')

		# Write the @label identifier to the .asm file  
		# which is provided to the function as well as providing 
		# an conditional jump instruction to the .asm file.
		self.outputFile.write('@' + label + '\n')
		self.outputFile.write('D;JNE' + '\n')

	def writeCall(self, functionName, numArgs):

		# Writes assembly code that effects the call command.
		# Accepts functionName(string) & numArgs(int) arguments.

		# Write the functionName# identifier to the .asm file 
		# which is provided to the function as well as calculating 
		# the offset from the numArgs provided to the function.
		offset = int(numArgs) + 5
		self.outputFile.write('@' + functionName + str(self.labelIndexer) + '\n')
		self.outputFile.write('D=A' + '\n')

		# Increment the label indexer.
		self.labelIndexer += 1

		# Push D onto stack:
		self.outputFile.write('@SP' + '\n')
		self.outputFile.write('A=M' + '\n')
		self.outputFile.write('M=D' + '\n')

		# Increment StackPointer:
		self.outputFile.write('@SP' + '\n')
		self.outputFile.write('M=M+1' + '\n')

		# Write the segment address identifiers to the .asm file. 
		for iterator in ('LCL','ARG','THIS','THAT'): 

			# Address of Segments
			self.outputFile.write('@' + iterator + '\n')
			self.outputFile.write('D=M' + '\n')

			# Push D onto stack:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=D' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n')

		# Write the offset address identifier for the argument to the .asm file. 
		self.outputFile.write('@SP' + '\n')          
		self.outputFile.write('D=M' + '\n')
		self.outputFile.write('@' + str(offset) + '\n')
		self.outputFile.write('D=D-A' + '\n')
		self.outputFile.write('@ARG' + '\n')
		self.outputFile.write('M=D' + '\n')  

		# Write the address identifier for the local to the .asm file.    
		self.outputFile.write('@SP' + '\n')             
		self.outputFile.write('D=M' + '\n')
		self.outputFile.write('@LCL' + '\n')
		self.outputFile.write('M=D' + '\n')

		# Write the label and goto commands to the .asm file for function.
		self.writeGoto(functionName)
		self.writeLabel(functionName + str(self.labelIndexer))

	def writeReturn(self):

		# Writes assembly code that effects the return command.
		
		# Write the local variable to the temporary R5 register.
		self.outputFile.write('@LCL' + '\n')        
		self.outputFile.write('D=M' + '\n')
		self.outputFile.write('@R5' + '\n')
		self.outputFile.write('M=D' + '\n') 
		self.outputFile.write('D=M' + '\n')         

		# Write the return argument from the called function.
		self.outputFile.write('@5' + '\n')
		self.outputFile.write('D=D-A' + '\n')
		self.outputFile.write('@R6' + '\n')
		self.outputFile.write('M=D' + '\n')      

		# Decrement StackPointer:
		self.outputFile.write('@SP' + '\n')
		self.outputFile.write('M=M-1' + '\n')

		# Pop top of stack to D:
		self.outputFile.write('@SP' + '\n')
		self.outputFile.write('A=M' + '\n')
		self.outputFile.write('D=M' + '\n')

		# Write the argument return value for the caller.
		self.outputFile.write('@ARG' + '\n')       
		self.outputFile.write('A=M' + '\n')
		self.outputFile.write('M=D' + '\n') 
		self.outputFile.write('@ARG' + '\n')    
		self.outputFile.write('D=M+1' + '\n')
		self.outputFile.write('@SP' + '\n')
		self.outputFile.write('M=D' + '\n')

		# Write 'that' segement.
		self.outputFile.write('@R5' + '\n') 
		self.outputFile.write('A=M-1' + '\n')
		self.outputFile.write('D=M' + '\n')
		self.outputFile.write('@THAT' + '\n')
		self.outputFile.write('M=D' + '\n')  

		# Write 'this' segement.
		self.outputFile.write('@R5' + '\n')
		self.outputFile.write('D=M' + '\n')
		self.outputFile.write('@2' + '\n')
		self.outputFile.write('A=D-A' + '\n')
		self.outputFile.write('D=M' + '\n')
		self.outputFile.write('@THIS' + '\n')
		self.outputFile.write('M=D' + '\n')

		# Write 'argument' segement.
		self.outputFile.write('@R5' + '\n')
		self.outputFile.write('D=M' + '\n')
		self.outputFile.write('@3' + '\n')
		self.outputFile.write('A=D-A' + '\n')
		self.outputFile.write('D=M' + '\n')
		self.outputFile.write('@ARG' + '\n')
		self.outputFile.write('M=D' + '\n')

		# Write 'local' segement.
		self.outputFile.write('@R5' + '\n')
		self.outputFile.write('D=M' + '\n')
		self.outputFile.write('@4' + '\n')
		self.outputFile.write('A=D-A' + '\n')
		self.outputFile.write('D=M' + '\n')
		self.outputFile.write('@LCL' + '\n')
		self.outputFile.write('M=D' + '\n')

		# Write the return address.
		self.outputFile.write('@R6' + '\n') 
		self.outputFile.write('A=M' + '\n')

	def writeFunction(self, functionName, numLocals):

		# Writes assembly code that effects the function command.
		# Accepts functionName(string) & numLocals(int) arguments.

		# Creation of a label for the function name.
		self.writeLabel(functionName)

		# Creation of local variables for the function.
		for iterator in range(int(numLocals)):

			# Write the memory address for locals.
			self.outputFile.write('@0' + '\n')
			self.outputFile.write('D=A' + '\n')

			# Push D onto stack:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('A=M' + '\n')
			self.outputFile.write('M=D' + '\n')

			# Increment StackPointer:
			self.outputFile.write('@SP' + '\n')
			self.outputFile.write('M=M+1' + '\n')

	def Close(self):

        # Closes the output file.

        # Creates infinite loop at the end of .asm source file:
		endLabel = 'END'
		self.writeLabel(endLabel)
		self.writeGoto(endLabel)

		# Closes the outputFile:
		self.outputFile.close
