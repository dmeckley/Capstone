Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 08
File Name: README.txt

1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
The WriteLabel, writeGoto, and writeIf were pretty straightforward for the most part and easy to accomplish without too many troubles.   

2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
The writeInit, writeCall, writeReturn, and writeFuntion were all fairly difficult and time consuming to complete.  Also, figuring out how to handle a single directory of multiple files was very confusing and time-consuming.

3. Estimate how long you worked on the project.
-----------------------------------------------
Textbook Reading: 2 hours.
main.py: 1 hour.
VMTranslator.py: 2 hours.
Parser.py: 1 hour.
CodeWriter.py: 12 hours.
README.txt: 1 hour.
Requirement & Design: 2 hours.
Code and Test: 20 hours altogether.

4. Describe how to build/compile your translator code.
------------------------------------------------------
 Use the following commandline input syntax for program compilation build(s):
					python main.py fileName.vm
					        or
					python main.py fullPathDirectoryName\
This program was designed and constructed around utilizing the Windows Powershell
utilizing python v3.5.


5. Instructions describing how to use your translator.
------------------------------------------------------
main.py accepts the full directory path with a '\' appended to the end of the
the directory path or the filename.vm through the commandline argument which is 
then passed into the VMtranslator object as an argument.

VMtranslator.py accepts the inputFile from the main.py program VMtranslator object 
instance and determines if a directory path is provided or a filename is provide.  
Based on this logical decision either the directoryExecution() method is processed 
a single directory with multiple files or the fileExecution() method is processed for
a single file input from the commandline argument.  This does most of the processing for 
the Parser.py and CodeWriter.py objects.

The Parser.py object accepts the inputFile from VMtranslator.py object instance and processes 
the inputFile to be read and for the data to be parsed within the file(s).

The CodeWriter.py object accepts the outputFile from VMtranslator.py object instance and processes the outputFile to be written to and for the .asm instructions to be created for the arithmetic, memory, flow, and function implementations.  As well as it contains the bootstrap code.  

6. Comments on any part(s) of the translator project that doesn't work and attempts to solve it.
------------------------------------------------------------------------------------------------
Right now, I have got the code to work for the 1st three test cases verifying that both the flow and function operations work correctly.  It was only when I implemented the directory with multiple-files that my program still does not seem to work correctly for the last two remaining test cases.  Line # 47 of the CodeWriter.py object must be commented out in order to run the first three tests but must then be uncommented to run the remaining two tests.  