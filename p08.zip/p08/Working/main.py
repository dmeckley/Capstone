# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 08
# File Name: main.py

from sys import *
from VMtranslator import *

if __name__ == '__main__':
  
    # Main program execution:
    # Accepts commandline arguments from the user
    # and catches an exception if the file does not 
    # exist or the input from the user is invalid.

    # Local Variable Declaration and Initialization.
    inputFile = ''

    # Accept fileName.vm as commandline argument and create an
    # VMtranslator object instance passing in the inputFile.  
    # Call VMtranslator execution() method with object instance
    # to perform proper execution.
    # Handle exceptions if problems occur with file or object 
    # instance creation.
    try:
        inputFile = argv[1]
        vm = VMtranslator(inputFile)
        vm.execution()
    except IOError as exception:
        text = 'FileNotFoundError: ' + str(exception)
        print()
        for iterator in text:
            print('-', end='')
        print()
        print(text)
        for iterator in text:
            print('-', end='')
        print('\n')
    except IndexError as exception:
        text = 'IndexError: ' + str(exception)
        print()
        for iterator in text:
            print('-', end='')
        print()
        print(text)
        for iterator in text:
            print('-', end='')
        print('\n')
