Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 08
File Name: README.txt

1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
The WriteLabel, writeGoto, and writeIf were pretty straightforward for the most part and easy to accomplish.   

2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
The writeInit, writeCall, writeReturn, and writeFuntion were all fairly difficult and time consuming to complete.  Also, figuring out how to handle a single directory of multiple files was very confusing and time-consuming.

3. Estimate how long you worked on the project.
-----------------------------------------------
Textbook Reading: 2 hours.
main.py:
VMTranslator.py:
Parser.py:
CodeWriter.py:
README.txt:
Requirement & Design:
Code and Test:

4. Describe how to build/compile your translator code.
------------------------------------------------------
Utilizes python v3.5 using the following commandline input for program compilation build:
					python main.py fileName_or_directoryName


5. Instructions describing how to use your translator.
------------------------------------------------------


6. Comments on any part(s) of the translator project that doesn't work and attempts to solve it.
------------------------------------------------------------------------------------------------
