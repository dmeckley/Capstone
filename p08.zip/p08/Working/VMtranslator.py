# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 08
# File Name: VMtranslator.py

from Parser import *
from CodeWriter import *

class VMtranslator(object):

    # VMtranslator Data Attributes:

    def __init__(self, inputFile):

        # Setup/Initialization of the VMtranslator object:

        # VMtranslator Object Data Attribute Initialization:
        self.inputFile = inputFile
        self.outputFile = (inputFile.replace('.vm', '.asm') 
            if inputFile.endswith('.vm') 
            else inputFile + '.asm')

    def execution(self):

        # Execution of the VMtranslator object:

        # Performs the execution of the program.
        parser = Parser(self.inputFile)
        codeWriter = CodeWriter(self.outputFile)
        codeWriter.setFileName(self.outputFile[:-3])
        while parser.hasMoreCommands():
            parser.advance()
            commandType = parser.commandType()
            if commandType == 'C_ARITHMETIC':
               codeWriter.writeArithmetic(parser.command)
            elif commandType == 'C_PUSH' or commandType == 'C_POP':
                if 'pop' in parser.command:
                    command = 'pop'
                else:
                    command = 'push'
                segment = parser.arg1()
                index = parser.arg2()
                codeWriter.WritePushPop(command, segment, index)
            elif commandType == 'C_LABEL':
                label = parser.arg1()
                codeWriter.writeLabel(label)
            elif commandType == 'C_GOTO':
                label = parser.arg1()
                codeWriter.writeGoto(label)
            elif commandType == 'C_IF':
                label = parser.arg1()
                codeWriter.writeIf(label)

            elif commandType == 'C_FUNCTION':
                # functionName = parser.arg1().replace('.','$')
                functionName = parser.arg1()
                if functionName.find('.') != -1:
                    functionName = functionName.replace('.', '$')
                numLocals = parser.arg2()
                codeWriter.writeFunction(functionName, numLocals)
            elif commandType == 'C_RETURN':
                codeWriter.writeReturn()
            elif commandType == 'C_CALL':
                # functionName = parser.arg1().replace('.','$')
                functionName = parser.arg1()
                if functionName.find('.') != -1:
                    functionName = functionName.replace('.', '$')
                numArgs = parser.arg2()
                codeWriter.writeCall(functionName, numArgs)  
            # codeWriter.outputFile.write('@22222' + '\n')  

        codeWriter.Close()
        

