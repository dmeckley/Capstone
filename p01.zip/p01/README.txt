Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 01
File Name: README.txt

1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------
After completing the basic Not, And, Or, Xor, Mux, and DMux chips; the other remaining chips were fairly easy to complete. 

2. Describe something that was difficult, confusing, or time-consuming about the project.
---------------------------------------------------------------
Figuring out the intitial Not, And, Or, Xor, Mux, and DMux chips with only the capability of using Nand gates was a major pain.  

3. Estimate how long you worked on the project.
-----------------------------------------------
Approximately 8 hours were spent on this portion of the project and I was not able to get them all complete because I ran out of time due to a stupid head cold that had me down and out for almost four days now.  I will post the remaining ones when I am finished with them sometime tomorrow.  Thank you!