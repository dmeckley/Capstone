# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 10
# File: JackTokenizer.py


# Global Data Attributes: 
# -----------------------

# Tokens:
TOKENTYPE_KEYWORD = 1
TOKENTYPE_SYMBOL = 2
TOKENTYPE_IDENTIFIER = 3
TOKENTYPE_INT_CONST = 4
TOKENTYPE_STRING_CONST = 5

token_names = {
	TOKENTYPE_KEYWORD: "keyword",
	TOKENTYPE_SYMBOL: "symbol",
	TOKENTYPE_IDENTIFIER: "identifier",
	TOKENTYPE_INT_CONST: "integerConstant",
	TOKENTYPE_STRING_CONST: "stringConstant" }


# Keywords:
KEYWORD_CLASS = 1
KEYWORD_METHOD = 2
KEYWORD_FUNCTION = 3
KEYWORD_CONSTRUCTOR = 4
KEYWORD_INT = 5
KEYWORD_BOOLEAN = 6
KEYWORD_CHAR = 7
KEYWORD_VOID = 8
KEYWORD_VAR = 9
KEYWORD_STATIC = 10
KEYWORD_FIELD = 11
KEYWORD_LET = 12
KEYWORD_DO = 13
KEYWORD_IF = 14
KEYWORD_ELSE = 15
KEYWORD_WHILE = 16
KEYWORD_RETURN = 17
KEYWORD_TRUE = 18
KEYWORD_FALSE = 19
KEYWORD_NULL = 20
KEYWORD_THIS = 21

keyword_types = {
	"class": KEYWORD_CLASS,
	"method": KEYWORD_METHOD,
	"function": KEYWORD_FUNCTION,
	"constructor": KEYWORD_CONSTRUCTOR,
	"int": KEYWORD_INT,
	"boolean": KEYWORD_BOOLEAN,
	"char": KEYWORD_CHAR,
	"void": KEYWORD_VOID,
	"var": KEYWORD_VAR,
	"static": KEYWORD_STATIC,
	"field": KEYWORD_FIELD,
	"let": KEYWORD_LET,
	"do": KEYWORD_DO,
	"if": KEYWORD_IF,
	"else": KEYWORD_ELSE,
	"while": KEYWORD_WHILE,
	"return": KEYWORD_RETURN,
	"true": KEYWORD_TRUE,
	"false": KEYWORD_FALSE,
	"null": KEYWORD_NULL,
	"this": KEYWORD_THIS }


# Symbols:
symbols = "{}()[].,;+-*/&|<>=~"

symbol_names = {
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"&": "&amp;" }


# Static Functions: 
# -----------------

# Remove all comments:
def remove_comments(lines):
	return remove_multiline_comments(remove_singleline_comments(lines))


# Remove single-line comments:
def remove_singleline_comments(lines):
	new_lines = []
	for line in lines:
		pos = line.find("//")
		new_line = line[:pos] if pos != -1 else line
		if new_line and not new_line.isspace():
			new_lines.append(new_line)
	return new_lines


# Remove multi-line comments:
def remove_multiline_comments(lines):
	text = "".join(lines)
	while True:
		pos1 = text.find("/*")
		if pos1 == -1:
			break
		pos2 = text.find("*/") + 2
		text = "".join([text[:pos1], text[pos2:]])
	return text


# Separates literal strings into segments:
def split_string_consts(segments):
	new_segments = []
	for segment in segments:
		while not segment.isspace():
			pos1 = segment.find("\"")
			if pos1 == -1:
				new_segments.append(segment)
				break
			else:
				pos2 = segment.find("\"", pos1 + 1)
				new_segments.append(segment[:pos1])
				new_segments.append(segment[pos1:(pos2 + 1)])
				segment = segment[(pos2 + 1):]
	return new_segments


# Separates tokens by spaces:
def split_by_spaces(segments):

	# Removes the spaces
	new_segments = []
	for segment in segments:
		if segment.startswith("\"") and segment.endswith("\""): # this is a literal string
			new_segments.append(segment)
		else:
			new_segments += segment.split(" ")

	# Remove the newlines:
	new_segments2 = []
	for segment in new_segments:
		if segment.startswith("\"") and segment.endswith("\""):
			new_segments2.append(segment)
		else:
			new_segments2 += segment.split("\n")

	# Returns the non-blank lines:
	return [segment.strip() for segment in new_segments2 if segment != "" and not segment.isspace()]


# Separates tokens by symbols:
def split_by_symbols(segments):

	new_segments = []
	for segment in segments:
		if segment.startswith("\"") and segment.endswith("\""): # this is a literal string
			new_segments.append(segment)
		else:
			while segment != "":
				for i in range(0, len(segment)):
					if symbols.find(segment[i]) != -1:
						new_segments.append(segment[:i])
						new_segments.append(segment[i:(i + 1)])
						segment = segment[(i + 1):]
						break
					elif i == len(segment) - 1:
						new_segments.append(segment)
						segment = ""

	# Returns the non-blank lines:
	return [segment.strip() for segment in new_segments if segment != "" and not segment.isspace()]


# Returns boolean true when token isdigit:
def is_integer(token):
	if token[0] in ('-', '+'):
		return token[1:].isdigit()
	else:
		return token.isdigit()


# ---------------------------------------
# | 	JackTokenizer Object Class: 	| 
# ---------------------------------------
class JackTokenizer(object):


	# JackTokenizer Methods: 
	# ----------------------

	# JackTokenizer Constructor:
	def __init__(self, file_name):
		with open(file_name) as f:
			lines1 = f.readlines()
			lines2 = remove_singleline_comments(lines1)
			text = remove_multiline_comments(lines2)
			segments1 = split_string_consts([text])
			segments2 = split_by_spaces(segments1)
			self.tokens = split_by_symbols(segments2)
			self.current = -1


	# Returns boolean true when more tokens:
	def hasMoreTokens(self):
		return self.current < len(self.tokens) - 1


	# Advance to next token and make current token:
	def advance(self):
		self.current += 1


	# Returns type of current token:
	def tokenType(self):
		if self.tokens[self.current] in keyword_types:
			return TOKENTYPE_KEYWORD
		elif symbols.find(self.tokens[self.current]) != -1:
			return TOKENTYPE_SYMBOL
		elif self.tokens[self.current][0] == "\"" and self.tokens[self.current][-1] == "\"":
			return TOKENTYPE_STRING_CONST
		elif is_integer(self.tokens[self.current]):
			return TOKENTYPE_INT_CONST
		else:
			return TOKENTYPE_IDENTIFIER


	# Returns the keyword of current token:
	def keyWord(self):
		return keyword_types[self.tokens[self.current]]


	# Returns the symbol of current token:
	def symbol(self):
		s = self.tokens[self.current]
		return symbol_names[s] if s in symbol_names else s


	# Returns identifier of current token:
	def identifier(self):
		return self.tokens[self.current]


	# Returns integer value of current token:
	def intVal(self):
		return int(self.tokens[self.current])


	# Returns string value of current token:
	def stringVal(self):
		return self.tokens[self.current][1:-1]


	# Returns current token:
	def getToken(self):
		return self.tokens[self.current]


	# Returns next token:
	def getLookaheadToken(self):
		return self.tokens[self.current + 1]



