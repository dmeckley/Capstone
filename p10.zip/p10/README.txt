Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 10
File: README.txt


1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
It taught me way more about how the Lexical Analyzer and the Syntactical Analyzer phases of a compiler works as compared to what was taught during my Programming Languages course.  However, I didn't really feel that the course prepared me for building a compiler in this course at all.

Producing the methods specified by the textbook for the JackTokenizer.py class was not too bad since it was similar to when we did the Virtual Machine assembler.  


2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
Finally, figuring out how to be able to provide both the individual paths for individual files and the ability to also include paths for directory to convert all of the files into .xml files was my first obstacle that took a lot of time to learn how to do on my own.  

Next, figuring out how all of the compilation process worked so I can figure out my requirements and design process took a lot of time as well since I pretty much had to teach myself, yet once again, how all of this works together.

Next, figuring out how to remove comments and separating tokens, symbols, and strings out took a little time to figure out.

Finally, the CompilationEngine.py took the longest and basically was a major pain in the ass to figure everything out.  This took me the majority of the time on this project to figure out and code.


3. Estimate how long you worked on the project.
-----------------------------------------------
Reading:                 2 hours    
Requirements and Design: 5 hours
JackAnalyzer.py:		12 hours
JackTokenizer.py:		 4 hours
CompilationEngine.py: 	24 hours
README.txt:				 1 hour
--------------------------------
Coding and Testing:		40 hours
================================
Total:					48 hours	


4. Describe how to build/compile the compiler code.
---------------------------------------------------
This program was built using Python3.5.2.

On the command line, input python JackAnalyzer.py and either the directory path containing the .jack files or the path for each individual .jack file itself.  

1) Directory:
Using the ArrayTest directory placed within the C drive for an example, the user should input "python JackAnalyzer.py C:\ArrayTest\" without double quotes for all of the .xml files to be created from all of the .jack files within that directory.

2) Individual Files:
Using the Main.jack file within the ArrayTest directory for an example, the user should input "python JackAnalyzer.py C:\ArrayTest\Main.jack" without double quotes for all of the Main.xml files to be created for each of the Main.jack files within that directory.  This must be repeated for each unique .jack file in that directory in order to create all of the .xml files for the whole directory.


5. Describe the instructions how to use the compiler.
-----------------------------------------------------
After the compilation process is complete, then there should exist two separate .xml files for each unique .jack file within each of the directories provided where:

Step 1) fileName.T.xml --> Tokenizer File.
Step 2) fileName.xml --> Parser File.

Testing the Tokenizer Files:
----------------------------
The book states to use the TextComparer.bat application to compare the Tokenizer fileName.T.xml output file to the nand2tetris supplied fileName.T.xml file but since I have never been able to get my TextComparer.bat nor my JackCompiler.bat to ever work properly on my machine, I just compared the output fileName.T.xml file that my built compiler produced with the fileName.T.xml file provided by the nand2tetris software download from the website by using Sublime Text 3 Side by Side Compare Package.

Testing the Parser Files:
-------------------------
I did the same thing that I did above for my Tokenizer file for my Parser file.  I took the compiler output for the Parser named fileName.xml that I built and compared it with the output fileName.xml provided by the nand2tetris software download from the website using Sublime Text 3 Side by Side Compare Package.   


6. Comments on any part of the compiler project which doesn't work properly and attempts to solve it.
-----------------------------------------------------------------------------------------------------
It seems to all work according to my test procedures with the Sublime Text 3 Side by Side Compare Package; however, I don't know if you will find this adequate for a thourough testing procedure but I had to do what I could because my TextComparer.bat nor my JackCompiler.bat have never worked on my machine.  Therefore, I hope this is adequate enough for you!
