Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 11
File: README.txt


1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
I found this portion of the project a lot easier to implement as compared to completing project # 10. The majority of my time was spent on commenting out the old .xml code and replacing it with .vm code in the CompilationEngine.py source code file.  Also, a significant amount of time was spent on the SymbolTable.py and VMWriter.py source code files.  I found that this project was interesting, even though it was so time consuming because it taught me a lot about Compilers and how they work since I was never able to take the Compilers course here like I had hoped.  I really didn't find anything easy about this project but completing project # 11 was a lot easier after spending so much time on project # 10.


2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
I think the most complicated portion of this project was determining the requirements and design of the SymbolTable.py and finding all of the .xml portions of the CompilationEngine.py source code and determining the modifications needed to implement all of the .vm portions of the CompilationEngine.py instead.  


3. Estimate how long you worked on the project.
-----------------------------------------------
Reading:   					2 hour(s)                  
Requirements and Design: 	3 hour(s)   
JackCompiler.py:			1 hour(s)   	
JackTokenizer.py:			1 hour(s)   		 
CompilationEngine.py: 		8 hour(s)   
SymbolTable.py:				8 hour(s)   
VMWriter.py					8 hour(s)   
README.txt:					1 hour(s) 							 
--------------------------------------
Coding and Testing:			26 hour(s) 	
======================================
Total:						32 hour(s)					


4. Describe how to build/compile the compiler code.
---------------------------------------------------
This program was built using Python3.5.2.

On the command line, input python JackCompiler.py and either the directory path containing the .jack files or the path for each individual .jack file itself.  

1) Directory:
Using the Square directory placed within the C drive for an example, the user should input "python JackCompiler.py C:\Square\" without double quotes for all of the .vm files to be created from all of the .jack files within that directory.

2) Individual Files:
Using the Main.jack file within the Square directory for an example, the user should input "python JackCompiler.py C:\Square\Main.jack" without double quotes for all of the Main.vm files to be created for each of the Main.jack files within that directory.  This must be repeated for each unique .jack file in that directory in order to create all of the .vm files for the whole directory.


5. Describe the instructions how to use the compiler.
-----------------------------------------------------
After the compilation process is complete, then there should exist one .vm file for each unique .jack file within each of the directories provided where:

fileName.jack --> fileName.vm

Testing the .vm Files:
----------------------------
After converting each of the .jack files independently or converting all of the .jack files within a directory to .vm files, open the VMEmulator.bat software to test the .vm files.  After opening up the VMEmulator software, click on the File --> Load Program --> Select directory of .vm files to execute --> Load Program.  After the program is loaded up click on the Run --> Run(F5) --> Program executes successfully, then everything is awesome with the compiler.


6. Comments on any part of the compiler project which doesn't work properly and attempts to solve it.
-----------------------------------------------------------------------------------------------------
It seems to all work according to the testing procedures provided.  After all of the .jack files within the directory are converted to .vm files, the VMEmulator.bat can be used to run the directory of .vm files to verify that the program executed according to specifications.  I have ran all the tests available on the VMEmulator software and they have all passed the qualifications.