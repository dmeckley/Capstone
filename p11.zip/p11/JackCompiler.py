# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 11
# File: JackCompiler.py


# Import Statement(s):
import sys
import os
from JackTokenizer import *
from CompilationEngine import *


# Format Output --> Token Type:
def testTokenizer(jackTokenizer):

	# Local Variable Declaration and Initialization:
	output = "<tokens>\n"

	# More Tokens to Process --> Advance:
	while jackTokenizer.hasMoreTokens():
		jackTokenizer.advance()
		if jackTokenizer.tokenType() == TOKENTYPE_KEYWORD:
			output += "<keyword> {0} </keyword>\n".format(jackTokenizer.getToken())
		elif jackTokenizer.tokenType() == TOKENTYPE_SYMBOL:
			output += "<symbol> {0} </symbol>\n".format(jackTokenizer.symbol())
		elif jackTokenizer.tokenType() == TOKENTYPE_STRING_CONST:
			output += "<stringConstant> {0} </stringConstant>\n".format(jackTokenizer.stringVal())
		elif jackTokenizer.tokenType() == TOKENTYPE_INT_CONST:
			output += "<integerConstant> {0} </integerConstant>\n".format(jackTokenizer.intVal())
		elif jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
			output += "<identifier> {0} </identifier>\n".format(jackTokenizer.identifier())

	# Return:
	return output + "</tokens>\n"


# Main Function Program Execution:
if __name__ == "__main__":  
	
	# Local Variable Declaration and Initialization:
	files = []

	# Commandline Input:
	if len(sys.argv) != 2:
		print("Usage1:   python JackCompiler.py <file>")
		print("Usage2:   python JackCompiler.py <directory>")
		print("Example1: python JackCompiler.py C:\\Nand2Tetris\\P11\\Square\\square.jack")
		print("Example2: python JackCompiler.py C:\\Nand2Tetris\\P11\\Square\\")
		sys.exit()

	# File Input:
	elif os.path.isfile(sys.argv[1]):
		files = [sys.argv[1]]

	# Directory Input:
	elif os.path.isdir(sys.argv[1]):
		path = sys.argv[1]
		if not sys.argv[1].endswith("/") and not sys.argv[1].endswith("\\"):
			path += "/"
		for file_name in os.listdir(sys.argv[1]):
			if file_name.endswith(".jack"):
				input_file_name = path + file_name
				files.append(input_file_name)
			pass
		pass
		
	# Invalid Input:
	else:
		print("Invalid argument! Must be either a file or directory")
		sys.exit()

	# Program Execution:
	for input_file_name in files:

		# Tokenizer File Execution:
		jackTokenizer = JackTokenizer(input_file_name)
		output = testTokenizer(jackTokenizer)
		# output_file_name1 = input_file_name[:-5] + ".T.xml"
		# with open(output_file_name1, "w") as f:
		# 	f.write(output)
		# print("tokenize output written to file {0}\n".format(output_file_name1))

		# Parser File Execution:
		compilationEngine = CompilationEngine(input_file_name)
		output = compilationEngine.CompileClass("")
		output_file_name2 = input_file_name[:-5] + ".vm"
		with open(output_file_name2, "w") as f:
			f.write(output)
		print("parse output written to file {0}\n\n".format(output_file_name2))

