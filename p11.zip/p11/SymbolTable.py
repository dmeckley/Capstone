# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 11
# File: SymbolTable.py


# Import Statement(s):
from collections import OrderedDict


# Global Data Attributes: 
# -----------------------

# Symbols:
SYMBOL_KIND_NONE = 0
SYMBOL_KIND_VAR = 1
SYMBOL_KIND_ARG = 2
SYMBOL_KIND_FIELD = 3
SYMBOL_KIND_STATIC = 4

segments = ["none", "local", "argument", "this", "static"]


# ---------------------------------------
# | 	 SymbolTable Object Class:  	| 
# ---------------------------------------
class SymbolTable(object):

	# SymbolTable Methods: 
	# --------------------

	# SymbolTable Constructor:
	def __init__(self):

		# Object Variable Declaration and Initialization:
		self.symbols = [OrderedDict() for i in range(5)]


	# Starts --> new subroutine scope:
	def startsSubroutine(self, isMethod):

		self.symbols[SYMBOL_KIND_VAR].clear()
		self.symbols[SYMBOL_KIND_ARG].clear()
		if isMethod:
			self.symbols[SYMBOL_KIND_ARG]["this"] = "void" 


	# Defines --> new identifier:
	def Define(self, name, type, kind):

		self.symbols[kind][name] = type

	
	# Returns the number of variables --> given kind already defined in the current scope:	
	def VarCount(self, kind):

		# Return:
		return len(self.symbols[kind])


	# Returns the kind --> named identifier in the current scope:
	def KindOf(self, name):

		for i in range(1, 5):
			if name in self.symbols[i].keys():

				# Return:
				return i

		# Return:
		return SYMBOL_KIND_NONE


	# Returns the type --> named identifier in the current scope:
	def TypeOf(self, name):

		for i in range(1, 5):
			if name in self.symbols[i].keys():

				# Return:
				return self.symbols[i][name]

		# Return:
		return SYMBOL_TYPE_NONE


	# Returns the index assignment --> named identifier:
	def IndexOf(self, name):

		for i in range(1, 5):
			if name in self.symbols[i].keys():

				# Return:
				return list(self.symbols[i].keys()).index(name)

		# Return:
		return -1


	# Returns segment and index --> If Symbol Table contains the Provided Segment:
	def SegmentIndexOf(self, name):

		for i in range(1, 5):
			if name in self.symbols[i].keys():
				segment = segments[i]
				index = list(self.symbols[i].keys()).index(name)

				# Return:
				return segment, index

		# Return:
		return None, None


	# Returns True --> If Symbol Table contains the Provided Symbol:
	def ContainsSymbol(self, name):

		for i in range(1, 5):
			if name in self.symbols[i].keys():
				
				# Return:
				return True

		# Return:
		return False
