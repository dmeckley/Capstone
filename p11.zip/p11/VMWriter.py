# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 11
# File: VMWriter.py


# Global Data Attributes: 
# -----------------------

# Segment(s):
SEGMENT_NONE = 0
SEGMENT_CONST = 1
SEGMENT_ARG = 2
SEGMENT_LOCAL = 3
SEGMENT_STATIC = 4
SEGMENT_THIS = 5
SEGMENT_THAT = 6
SEGMENT_POINTER = 7
SEGMENT_TEMP = 8

# Arithmetic(s):
ARITHMETIC_NONE = 0
ARITHMETIC_ADD = 1
ARITHMETIC_SUB = 2
ARITHMETIC_NEG = 3
ARITHMETIC_EQ = 4
ARITHMETIC_GT = 5
ARITHMETIC_LT = 6
ARITHMETIC_AND = 7
ARITHMETIC_OR = 8
ARITHMETIC_NOT = 9
ARITHMETIC_MUL = 10
ARITHMETIC_DIV = 11

arithmetic_operation_names = {
	ARITHMETIC_ADD: "add",
	ARITHMETIC_SUB: "sub",
	ARITHMETIC_NEG: "neg",
	ARITHMETIC_EQ: "eq",
	ARITHMETIC_GT: "gt",
	ARITHMETIC_LT: "lt",
	ARITHMETIC_AND: "and",
	ARITHMETIC_OR: "or",
	ARITHMETIC_NOT: "not",
	ARITHMETIC_MUL: "call Math.multiply 2",
	ARITHMETIC_DIV:  "call Math.divide 2"
}

arithmetic_binary_operations = {
	"+": ARITHMETIC_ADD,
	"-": ARITHMETIC_SUB,
	"=": ARITHMETIC_EQ,
	">": ARITHMETIC_GT,
	"<": ARITHMETIC_LT,
	"&": ARITHMETIC_AND,
	"|": ARITHMETIC_OR,
	"*": ARITHMETIC_MUL,
	"/": ARITHMETIC_DIV
}

arithmetic_unary_operations = {
	"-": ARITHMETIC_NEG,
	"~": ARITHMETIC_NOT
}


# ---------------------------------------
# | 	  VMWriter Object Class:    	| 
# ---------------------------------------
class VMWriter(object):

	# VMWriter Methods: 
	# -----------------

	# VMWriter Constructor:
	def __init__(self):

		# Pass:
		pass


	# Writes --> VM push command:
	def writePush(self, segment, index):

		# Local Variable Declaration and Initialization:
		output = "push {0} {1}\n".format(segment, index)

		# Return:
		return output


	# Writes --> VM pop command:
	def writePop(self, segment, index):

		# Local Variable Declaration and Initialization:
		output = "pop {0} {1}\n".format(segment, index)

		# Return:
		return output


	# Writes --> VM arithmetic command:
	def writeArithmetic(self, operation):

		# Return:
		return "{0}\n".format(arithmetic_operation_names[operation])


	# Writes --> VM label command:
	def writeLabel(self, label):

		# Return:
		return "label {0}\n".format(label)


	# Writes --> VM goto command:
	def writeGoto(self, label):

		# Return:
		return "goto {0}\n".format(label)


	# Writes --> VM if-goto command:
	def writeIf(self, label):

		# Return:
		return "if-goto {0}\n".format(label)


	# Writes --> VM call command:
	def writeCall(self, name, nArgs):

		# Return:
		return "call {0} {1}\n".format(name, nArgs)


	# Writes --> VM function command:
	def writeFunction(self, name, nLocals):

		# Return:
		return "function {0} {1}\n".format(name, nLocals)


	# Writes --> VM return command:
	def writeReturn(self):

		# Return:
		return "return\n"


	# Close --> output file:
	def close(self):

		# Pass:
		pass


