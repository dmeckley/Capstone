# Name: Dustin Meckley
# Course: ciss494 Senior Seminar in Computer Science
# Professor: Dr. Seth Warn
# Project: # 11
# File: CompilationEngine.py


# Import Statement(s):
import sys
from JackTokenizer import *
from SymbolTable import *
from VMWriter import *


# -------------------------------------------
# | 	CompilationEngine Object Class: 	| 
# -------------------------------------------
class CompilationEngine(object):

	# CompilationEngine Methods: 
	# --------------------------

	# CompilationEngine Constructor:
	def __init__(self, input_file_name, output_file_name = None):

		# Object Variable Declaration and Initialization:
		self.jackTokenizer = JackTokenizer(input_file_name)
		# self.output_file_name = output_file_name
		self.symbolTable = SymbolTable()
		self.vmWriter = VMWriter()
		self.className = ""
		self.whileCounter = 0
		self.ifCounter = 0


	# Compilation --> Class:
	def CompileClass(self, indent):

		# Local Variable Declaration and Initialization:
		# output =  indent + "<class>\n"
		output = ""

		# Advance:
		self.jackTokenizer.advance()

		# Keyword --> Class:
		if self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() == KEYWORD_CLASS:
			# output += indent + "  " + "<keyword> class </keyword>\n"

			# Advance:
			self.jackTokenizer.advance()

			# Identifier:
			if self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
				# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

				# self.className Identifier Assignment:
				self.className = self.jackTokenizer.identifier()

				# Advance:
				self.jackTokenizer.advance()

				# Symbol --> {:
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "{":
					# output += indent + "  " + "<symbol> { </symbol>\n"

					# Advance:
					self.jackTokenizer.advance()

					while True:

						# Keyword:
						if self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD:

							# Keyword --> Constructor, Function, or Method:
							if self.jackTokenizer.keyWord() in [KEYWORD_CONSTRUCTOR, KEYWORD_FUNCTION, KEYWORD_METHOD]:
								output += self.CompileSubroutine(indent + "  ")

							# Keyword --> Static or Field:
							elif self.jackTokenizer.keyWord() in [KEYWORD_STATIC, KEYWORD_FIELD]:
								output += self.CompileClassVarDec(indent + "  ")

							# Error:
							else:
								print("Error compiling the tokens! Program will abort.")
								sys.exit()

						else:

							# Break:
							break

					# Symbol --> }:
					if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "}":
						# output += indent + "  " + "<symbol> } </symbol>\n"
						# output +=  indent + "</class>\n"

						# Return:
						return output

		# Error:
		print("Error compiling the tokens! Program will abort.")
		sys.exit()


	# Compilation --> Static Declarations and Field Variables:
	def CompileClassVarDec(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<classVarDec>\n"

		# Keyword --> Static or Field:
		if self.jackTokenizer.keyWord() in [KEYWORD_STATIC, KEYWORD_FIELD]:
			# output += indent + "  " +  "<keyword> {0} </keyword>\n".format(self.jackTokenizer.getToken())
			
			# symbolKind --> Static or Field Kind of Symbol Assignment:
			symbolKind = SYMBOL_KIND_STATIC if self.jackTokenizer.keyWord() == KEYWORD_STATIC else SYMBOL_KIND_FIELD

			# Advance:
			self.jackTokenizer.advance()

			# Keyword --> Boolean, Char, Int, or Void:
			if self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() in [KEYWORD_BOOLEAN, KEYWORD_CHAR, KEYWORD_INT, KEYWORD_VOID]:
				# output += indent + "  " +  "<keyword> {0} </keyword>\n".format(self.jackTokenizer.getToken())

				# Pass:
				pass

			# Identifier:
			elif self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
				# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())
				
				# Pass:
				pass

			# Error:
			else:
				print("Error compiling the tokens! Program will abort.")
				sys.exit()

			# symbolType Assignment:
			symbolType = self.jackTokenizer.identifier()

			# Advance:
			self.jackTokenizer.advance()

			while True:

				# Identifier:
				if self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
					# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

					# symbolName --> Identifier Assignment:
					symbolName = self.jackTokenizer.identifier() 

					# Define a New Identifier:
					self.symbolTable.Define(symbolName, symbolType, symbolKind)

					# Advance:
					self.jackTokenizer.advance()

					# Symbol --> ,:
					if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ",":
						# output += indent + "  " + "<symbol> , </symbol>\n"

						# Advance:
						self.jackTokenizer.advance()

						# Continue:
						continue

					# Symbol --> ;:
					elif self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ";":
						# output += indent + "  " + "<symbol> ; </symbol>\n"
						# output += indent + "</classVarDec>\n"

						# Advance:
						self.jackTokenizer.advance()

						# Return:
						return ""

				# Error:
				else:
					print("Error compiling the tokens! Program will abort.")
					sys.exit()

		# Error:
		print("Error compiling the tokens! Program will abort.")
		sys.exit()


	# Compilation --> Method, Function, or Constructor:
	def CompileSubroutine(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<subroutineDec>\n"
		output = ""
		self.whileCounter = 0
		self.ifCounter = 0

		# Keyword --> Constructor, Function, or Method:
		if self.jackTokenizer.keyWord() in [KEYWORD_CONSTRUCTOR, KEYWORD_FUNCTION, KEYWORD_METHOD]:
			# output += indent + "  " +  "<keyword> {0} </keyword>\n".format(self.jackTokenizer.getToken())

			# functionType Assingment:
			functionType = self.jackTokenizer.keyWord()

			# Creates a New Subroutine Scope:
			self.symbolTable.startsSubroutine(functionType == KEYWORD_METHOD)

			# Advance:
			self.jackTokenizer.advance()

			# Keyword --> Boolean, Char, Int, or Void:
			if self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() in [KEYWORD_BOOLEAN, KEYWORD_CHAR, KEYWORD_INT, KEYWORD_VOID]:
				# output += indent + "  " +  "<keyword> {0} </keyword>\n".format(self.jackTokenizer.getToken())

				# Pass:
				pass

			# Identifier:
			elif self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
				# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

				# Pass:
				pass

			# Error:
			else:
				print("Error compiling the tokens! Program will abort.")
				sys.exit()

			# Advance:
			self.jackTokenizer.advance()

			# Identifier:
			if self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
				# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

				# functionName --> Identifier Assignment:
				functionName = self.jackTokenizer.identifier()

				# Advance:
				self.jackTokenizer.advance()

				# Symbol --> (:
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "(":
					# output += indent + "  " + "<symbol> ( </symbol>\n"

					# Advance:
					self.jackTokenizer.advance()

					# output += self.CompileParameterList(indent + "  ")
					self.CompileParameterList(indent + "  ")
					
					# Symbol --> ):
					if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ")":
						# output += indent + "  " + "<symbol> ) </symbol>\n"
						# output += indent + "  " + "<subroutineBody>\n"

						# Advance:
						self.jackTokenizer.advance()

						# Symbol --> {:
						if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "{":
							# output += indent + "    " + "<symbol> { </symbol>\n"

							# Advance:
							self.jackTokenizer.advance()

							# Keyword:
							while self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() == KEYWORD_VAR:
								# output += self.CompileVarDec(indent + "    ")
								# output += self.CompileStatements(indent + "    ")
								self.CompileVarDec(indent + "    ")
							output += self.vmWriter.writeFunction(self.className + "." + functionName, self.symbolTable.VarCount(SYMBOL_KIND_VAR))

							# Constuctor --> push constant, call Memory.alloc, and pop pointer:
							if functionType == KEYWORD_CONSTRUCTOR:
								output += self.vmWriter.writePush("constant", self.symbolTable.VarCount(SYMBOL_KIND_FIELD))
								output += self.vmWriter.writeCall("Memory.alloc", 1)
								output += self.vmWriter.writePop("pointer", 0)

							# Method --> push argument, and pop pointer:
							elif functionType == KEYWORD_METHOD:
								output += self.vmWriter.writePush("argument", 0)
								output += self.vmWriter.writePop("pointer", 0)
							output += self.CompileStatements(indent + "    ")

							# Symbol --> }:
							if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "}":
								# output += indent + "    " + "<symbol> } </symbol>\n"
								# output += indent + "  " + "</subroutineBody>\n"
								# output += indent + "</subroutineDec>\n"

								# Advance:
								self.jackTokenizer.advance()

								# Return:
								return output

		# Error:
		print("Error compiling the tokens! Program will abort.")
		sys.exit()


	# Compilation --> Parameter List:
	def CompileParameterList(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<parameterList>\n"

		while True:

			parameterType = ""

			# Symbol --> ):
			if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ")":

				# Break:
				break

			# Keyword --> Boolean, Char, Int, Void:
			elif self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() in [KEYWORD_BOOLEAN, KEYWORD_CHAR, KEYWORD_INT, KEYWORD_VOID]:
				# output += indent + "  " +  "<keyword> {0} </keyword>\n".format(self.jackTokenizer.getToken())

				# parameterType <-- Keyword Assignment:
				parameterType = self.jackTokenizer.getToken()

			# Identifier:
			elif self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
				# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

				# parameterType --> Identifier Assignment:
				parameterType = self.jackTokenizer.identifier()

			# Error:
			else:
				print("Error compiling the tokens! Program will abort.")
				sys.exit()

			# Advance:
			self.jackTokenizer.advance()

			# Identifier:
			if self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
				# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

				# parameterName --> Identifier Assignment:
				parameterName = self.jackTokenizer.identifier()

				# Define a New Identifier:
				self.symbolTable.Define(parameterName, parameterType, SYMBOL_KIND_ARG)

				# Advance:
				self.jackTokenizer.advance()

				# Symbol --> ,:
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ",":
					# output += indent + "  " + "<symbol> , </symbol>\n"

					# Advance:
					self.jackTokenizer.advance()

					# Continue:
					continue

				# Symbol --> ):
				elif self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ")":

					# Break:
					break

			# Error:
			print("Error compiling the tokens! Program will abort.")
			sys.exit()

		# output += indent + "</parameterList>\n"

		# Return:
		return 


	# Compilation --> Variable Declaration:
	def CompileVarDec(self, indent):

		# Local Variable Declaration and Initialization:
		# output = ""
		# output += indent + "<varDec>\n"
		# output += indent + "  " +  "<keyword> var </keyword>\n"

		# Advance:
		self.jackTokenizer.advance()

		varType = ""

		# Keyword --> Boolean, Char, Int, Void:
		if self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() in [KEYWORD_BOOLEAN, KEYWORD_CHAR, KEYWORD_INT, KEYWORD_VOID]:
			# output += indent + "  " +  "<keyword> {0} </keyword>\n".format(self.jackTokenizer.getToken())

			# varType --> Keyword Assignment:
			varType = self.jackTokenizer.getToken()

		# Identifier:
		elif self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
			# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

			# varType --> Identifier Assignment:
			varType = self.jackTokenizer.identifier()

		# Error:
		else:
			print("Error compiling the tokens! Program will abort.")
			sys.exit()

		# Advance:
		self.jackTokenizer.advance()

		while True:

			# Identifier:
			if self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
				# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

				# varName --> Identifier Assignment:
				varName = self.jackTokenizer.identifier()	
				
				# Define a New Identifier:
				self.symbolTable.Define(varName, varType, SYMBOL_KIND_VAR)			

				# Advance:
				self.jackTokenizer.advance()

				# Symbol --> ,:
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ",":
					# output += indent + "  " + "<symbol> , </symbol>\n"

					# Advance:
					self.jackTokenizer.advance()

					# Continue:
					continue

				# Symbol --> ;:
				elif self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ";":
					# output += indent + "  " + "<symbol> ; </symbol>\n"
					# output += indent + "</varDec>\n"

					# Advance:
					self.jackTokenizer.advance()

					# Return:
					return 

			# Error:
			print("Error compiling the tokens! Program will abort.")
			sys.exit()


	# Compilation --> Statements:
	def CompileStatements(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<statements>\n"
		output = ""

		while True:

			# Symbol --> }:
			if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "}":
				# output += indent + "</statements>\n"

				# Return:
				return output

			# Keyword --> do:
			elif self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() == KEYWORD_DO:
				output += self.CompileDo(indent + "  ")

				# Continue:
				continue

			# Keyword --> let:
			elif self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() == KEYWORD_LET:
				output += self.CompileLet(indent + "  ")

				# Continue:
				continue

			# Keyword --> if:
			elif self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() == KEYWORD_IF:
				output += self.CompileIf(indent + "  ")

				# Continue:
				continue

			# Keyword --> while:
			elif self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() == KEYWORD_WHILE:
				output += self.CompileWhile(indent + "  ")

				# Continue:
				continue

			# Keyword --> return:
			elif self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() == KEYWORD_RETURN:
				output += self.CompileReturn(indent + "  ")

				# Continue:
				continue

			# Error:
			else:
				print("Error compiling the tokens! Program will abort.")
				sys.exit()


	# Compilation --> Do Statement(s):
	def CompileDo(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<doStatement>\n"
		# output += indent + "  " + "<keyword> do </keyword>\n"
		output = ""
		className = self.className
		functionName = ""
		isInstance = False

		# Advance:
		self.jackTokenizer.advance()

		# Identifier:
		if self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
			# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

			# functionName --> Identifier Assignment:
			functionName = self.jackTokenizer.identifier()

		# Advance:
		self.jackTokenizer.advance()

		# Symbol --> .:
		if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ".":
			# output += indent + "  " + "<symbol> . </symbol>\n"

			# Advance:
			self.jackTokenizer.advance()

			# Identifier:
			if self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
				# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

				# className --> Identifier Assignment:
				className = functionName

				# If the symbolTable contains the className symbol, do:
				if self.symbolTable.ContainsSymbol(className):
					varName = className
					isInstance = True
					segment, index = self.symbolTable.SegmentIndexOf(varName)
					output += self.vmWriter.writePush(segment, index) 
					className = self.symbolTable.TypeOf(varName)
				functionName = self.jackTokenizer.identifier()

				# Advance:
				self.jackTokenizer.advance()

		# Symbol --> not(.):
		else:
			isInstance = True
			output += self.vmWriter.writePush("pointer", 0)

		# Symbol --> (:
		if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "(":
			# output += indent + "  " + "<symbol> ( </symbol>\n"

			# Advance:
			self.jackTokenizer.advance()

			# output += self.CompileExpressionList(indent + "  ")
			output1, nArgs = self.CompileExpressionList(indent + "  ")
			output += output1
			if isInstance:
				nArgs += 1

			# Symbol --> ):
			if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ")":
				# output += indent + "  " + "<symbol> ) </symbol>\n"
				output += self.vmWriter.writeCall(className + "." + functionName, nArgs)
				output += self.vmWriter.writePop("temp", 0)

				# Advance:
				self.jackTokenizer.advance()

				# Symbol --> ;:
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ";":
					# output += indent + "  " + "<symbol> ; </symbol>\n"
					# output += indent + "</doStatement>\n"

					# Advance:
					self.jackTokenizer.advance()

					# Return:
					return output

		# Error:
		print("Error compiling the tokens! Program will abort.")
		sys.exit()


	# Compilation --> Let Statement(s):
	def CompileLet(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<letStatement>\n"
		# output += indent + "  " + "<keyword> let </keyword>\n"
		output = ""
		isArray = False

		# Advance:
		self.jackTokenizer.advance()

		# Identifier:
		if self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
			# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

			# varName --> Identifier Assignment:
			varName = self.jackTokenizer.identifier()

			# segment and index Assignment --> symbolTable:
			segment, index = self.symbolTable.SegmentIndexOf(varName)

			# Advance:
			self.jackTokenizer.advance()

			# Symbol --> [:
			if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "[":
				# output += indent + "  " + "<symbol> [ </symbol>\n"
				isArray = True

				# Advance:
				self.jackTokenizer.advance()

				# output += self.CompileExpression(indent + "  ")
				output += self.CompileExpression(indent + "  ")
				output += self.vmWriter.writePush(segment, index)

				# Symbol --> ]:
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "]":
					# output += indent + "  " + "<symbol> ] </symbol>\n"
					output += self.vmWriter.writeArithmetic(ARITHMETIC_ADD)

					# Advance:
					self.jackTokenizer.advance()

				# Error:
				else:
					print("Error compiling the tokens! Program will abort.")
					sys.exit()

			# Symbol --> =:
			if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "=":
				# output += indent + "  " + "<symbol> = </symbol>\n"

				# Advance:
				self.jackTokenizer.advance()

				output += self.CompileExpression(indent + "  ")

				# If an array --> do:
				if isArray:
					output += self.vmWriter.writePop("temp", 0)
					output += self.vmWriter.writePop("pointer", 1)
					output += self.vmWriter.writePush("temp", 0)
					output += self.vmWriter.writePop("that", 0)

				# If not an array --> do:
				else:
					output += self.vmWriter.writePop(segment, index)

				# Symbol --> ;:
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ";":
					# output += indent + "  " + "<symbol> ; </symbol>\n"
					# output += indent + "</letStatement>\n"

					# Advance:
					self.jackTokenizer.advance()

					# Return:
					return output

		# Error:
		print("Error compiling the tokens! Program will abort.")
		sys.exit()


	# Compilation --> While Statement(s):
	def CompileWhile(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<whileStatement>\n"
		# output += indent + "  " + "<keyword> while </keyword>\n"
		whileCounter = self.whileCounter
		self.whileCounter += 1
		output = self.vmWriter.writeLabel("WHILE_EXP" + str(whileCounter))

		# Advance:
		self.jackTokenizer.advance()

		# Symbol --> (:
		if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "(":
			# output += indent + "  " + "<symbol> ( </symbol>\n"

			# Advance:
			self.jackTokenizer.advance()

			output += self.CompileExpression(indent + "  ")

			# Symbol --> ):
			if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ")":
				# output += indent + "  " + "<symbol> ) </symbol>\n"
				output += self.vmWriter.writeArithmetic(ARITHMETIC_NOT)
				output += self.vmWriter.writeIf("WHILE_END" + str(whileCounter))

				# Advance:
				self.jackTokenizer.advance()

				# Symbol --> {:
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "{":
					# output += indent + "  " + "<symbol> { </symbol>\n"

					# Advance:
					self.jackTokenizer.advance()

					output += self.CompileStatements(indent + "  ")

					# Symbol --> }:
					if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "}":
						# output += indent + "  " + "<symbol> } </symbol>\n"
						# output += indent + "</whileStatement>\n"
						output += self.vmWriter.writeGoto("WHILE_EXP" + str(whileCounter))
						output += self.vmWriter.writeLabel("WHILE_END" + str(whileCounter))

						# Advance:
						self.jackTokenizer.advance()

						# Return:
						return output

		# Error:
		print("Error compiling the tokens! Program will abort.")
		sys.exit()


	# Compilation --> Return Statement(s):
	def CompileReturn(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<returnStatement>\n"
		# output += indent + "  " + "<keyword> return </keyword>\n"
		output = ""

		# Advance:
		self.jackTokenizer.advance()

		# Symbol --> ;:
		if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ";":
			# output += indent + "  " + "<symbol> ; </symbol>\n"
			output += self.vmWriter.writePush("constant",  0)

		else:
			output += self.CompileExpression(indent + "  ")

			# Symbol --> ;:
			if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ";":
				# output += indent + "  " + "<symbol> ; </symbol>\n"

				# Pass:
				pass

			# Error:
			else:
				print("Error compiling the tokens! Program will abort.")
				sys.exit()

		# output += indent + "</returnStatement>\n"
		output += self.vmWriter.writeReturn()

		# Advance:
		self.jackTokenizer.advance()

		# Return:
		return output


	# Compilation --> If Statement(s):
	def CompileIf(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<ifStatement>\n"
		# output += indent + "  " + "<keyword> if </keyword>\n"
		ifCounter = self.ifCounter
		self.ifCounter += 1
		output = ""

		# Advance:
		self.jackTokenizer.advance()

		# Symbol --> (:
		if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "(":
			# output += indent + "  " + "<symbol> ( </symbol>\n"

			# Advance:
			self.jackTokenizer.advance()

			output += self.CompileExpression(indent + "  ")

			# Symbol --> ):
			if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ")":
				# output += indent + "  " + "<symbol> ) </symbol>\n"
				output += self.vmWriter.writeIf("IF_TRUE" + str(ifCounter))
				output += self.vmWriter.writeGoto("IF_FALSE" + str(ifCounter))
				output += self.vmWriter.writeLabel("IF_TRUE" + str(ifCounter))

				# Advance:
				self.jackTokenizer.advance()

				# Symbol --> {:
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "{":
					# output += indent + "  " + "<symbol> { </symbol>\n"

					# Advance:
					self.jackTokenizer.advance()

					output += self.CompileStatements(indent + "  ")

					# Symbol --> }:
					if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "}":
						# output += indent + "  " + "<symbol> } </symbol>\n"

						# Advance:
						self.jackTokenizer.advance()

						# Keyword --> else:
						if self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() == KEYWORD_ELSE:
							# output += indent + "  " + "<keyword> else </keyword>\n"
							output += self.vmWriter.writeGoto("IF_END" + str(ifCounter))
							output += self.vmWriter.writeLabel("IF_FALSE" + str(ifCounter))

							# Advance:
							self.jackTokenizer.advance()

							# Symbol --> {:
							if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "{":
								# output += indent + "  " + "<symbol> { </symbol>\n"

								# Advance:
								self.jackTokenizer.advance()

								output += self.CompileStatements(indent + "  ")

								# Symbol --> }:
								if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "}":
									# output += indent + "  " + "<symbol> } </symbol>\n"

									# Advance:
									self.jackTokenizer.advance()

									# output += indent + "</ifStatement>\n"
									output += self.vmWriter.writeLabel("IF_END" + str(ifCounter))

									# Return:
									return output

						else:
							# output += indent + "</ifStatement>\n"
							output += self.vmWriter.writeLabel("IF_FALSE" + str(ifCounter))

							# Return:
							return output

		# Error:
		print("Error compiling the tokens! Program will abort.")
		sys.exit()


	# Compilation --> Expression(s):
	def CompileExpression(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<expression>\n"
		output = self.CompileTerm(indent + "  ")

		# Symbol --> +, -, *, /, &, |, <>, or =:
		while self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.getToken() in "+-*/&|<>=":
			# output += indent + "  " + "<symbol> {0} </symbol>\n".format(self.jackTokenizer.symbol())

			# Symbol --> Binary Operation Operator:
			arithmeticBinaryOperation = arithmetic_binary_operations[self.jackTokenizer.symbol()]

			# Advance:
			self.jackTokenizer.advance()

			output += self.CompileTerm(indent + "  ")
			output += self.vmWriter.writeArithmetic(arithmeticBinaryOperation)

		# output += indent + "</expression>\n"

		# Return:
		return output


	# Compilation --> Term(s):
	def CompileTerm(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<term>\n"
		output = ""
		
		# Symbol --> Unary operation:
		if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() in "-~":
			# output += indent + "  " + "<symbol> {0} </symbol>\n".format(self.jackTokenizer.symbol())

			# Symbol --> Unary Operation Operator:
			arithmeticUnaryOperation = arithmetic_unary_operations[self.jackTokenizer.symbol()]

			# Advance:
			self.jackTokenizer.advance()

			output += self.CompileTerm(indent + "  ")
			output += self.vmWriter.writeArithmetic(arithmeticUnaryOperation)
			# output += indent + "</term>\n"

			# Return:
			return output

		# Integer Constant:
		elif self.jackTokenizer.tokenType() == TOKENTYPE_INT_CONST:
			# output += indent + "  " + "<integerConstant> {0} </integerConstant>\n".format(self.jackTokenizer.intVal())
			output += self.vmWriter.writePush("constant", self.jackTokenizer.intVal())

		# String Constant:
		elif self.jackTokenizer.tokenType() == TOKENTYPE_STRING_CONST:
			# output += indent + "  " + "<stringConstant> {0} </stringConstant>\n".format(self.jackTokenizer.stringVal())
			output += self.vmWriter.writePush("constant", len(self.jackTokenizer.stringVal()))
			output += self.vmWriter.writeCall("String.new", 1)
			for ch in self.jackTokenizer.stringVal():
				output += self.vmWriter.writePush("constant", ord(ch))
				output += self.vmWriter.writeCall("String.appendChar", 2)

		#  Keyword --> false, null, this, true, or void:
		elif self.jackTokenizer.tokenType() == TOKENTYPE_KEYWORD and self.jackTokenizer.keyWord() in [KEYWORD_FALSE, KEYWORD_NULL, KEYWORD_THIS, KEYWORD_TRUE, KEYWORD_VOID]:
			# output += indent + "  " + "<keyword> {0} </keyword>\n".format(self.jackTokenizer.getToken())
			if self.jackTokenizer.keyWord() == KEYWORD_FALSE:
				output += self.vmWriter.writePush("constant", 0)
			elif self.jackTokenizer.keyWord() == KEYWORD_NULL:
				output += self.vmWriter.writePush("constant", 0)
			elif self.jackTokenizer.keyWord() == KEYWORD_THIS:
				output += self.vmWriter.writePush("pointer", 0)
			elif self.jackTokenizer.keyWord() == KEYWORD_TRUE:
				output += self.vmWriter.writePush("constant", 0)
				output += self.vmWriter.writeArithmetic(ARITHMETIC_NOT)
			elif self.jackTokenizer.keyWord() == KEYWORD_VOID:
				output += self.vmWriter.writePush("constant", 0)

	#  Identifier:
		elif self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
			# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())

			# varName --> Identifier Assignment:
			varName = self.jackTokenizer.identifier();

			# Symbol --> . --> Next Token:
			if self.jackTokenizer.getLookaheadToken() == ".":

				# Advance:
				self.jackTokenizer.advance()

				# output += indent + "  " + "<symbol> . </symbol>\n"

				# Advance:
				self.jackTokenizer.advance()

				# Identifier --> Member Function Name:
				if self.jackTokenizer.tokenType() == TOKENTYPE_IDENTIFIER:
					# output += indent + "  " + "<identifier> {0} </identifier>\n".format(self.jackTokenizer.identifier())
					isInstance = False

					# functionName Identifier Assignment:
					functionName = self.jackTokenizer.identifier();

					# If symbolTable contains varName symbol --> do:
					if self.symbolTable.ContainsSymbol(varName):
						isInstance = True
						segment, index = self.symbolTable.SegmentIndexOf(varName)
						output += self.vmWriter.writePush(segment, index)
						className = self.symbolTable.TypeOf(varName)
					# If symbolTable not(contain) varName symbol --> do:
					else:
						className = varName

					# Advance:
					self.jackTokenizer.advance()

					# Symbol --> (:
					if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "(":
						# output += indent + "  " + "<symbol> ( </symbol>\n"

						# Advance:
						self.jackTokenizer.advance()

						# output += self.CompileExpressionList(indent + "  ")
						output1, nArgs = self.CompileExpressionList(indent + "  ") 
						output += output1
						if isInstance:
							nArgs += 1

						# Symbol --> ):
						if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ")":
							# output += indent + "  " + "<symbol> ) </symbol>\n"
							output += self.vmWriter.writeCall(className + "." + functionName, nArgs)

			# Symbol --> ( -->  Function Call:
			elif self.jackTokenizer.getLookaheadToken() == "(":
				if self.jackTokenizer.keyWord() == KEYWORD_METHOD:
					self.vmWriter.writePush("argument", 0) 

				# Advance:
				self.jackTokenizer.advance()

				# output += indent + "  " + "<symbol> ( </symbol>\n"

				# Advance:
				self.jackTokenizer.advance()

				# output += self.CompileExpressionList(indent + "  ")
				output1, nArgs = self.CompileExpressionList(indent + "  ") 
				output += output1

				# Symbol --> ):
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ")":
					# output += indent + "  " + "<symbol> ) </symbol>\n"
					self.vmWriter.writeCall(self.className + "." + functionName, nArgs)

			# Symbol --> [ --> Subscript:
			elif self.jackTokenizer.getLookaheadToken() == "[":

				# varName --> Identifier Assignment:
				varName = self.jackTokenizer.identifier()

				# Advance:
				self.jackTokenizer.advance()

				# output += indent + "  " + "<symbol> [ </symbol>\n"

				# Advance:
				self.jackTokenizer.advance()

				output += self.CompileExpression(indent + "  ")

				# Symbol --> ]:
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "]":
					# output += indent + "  " + "<symbol> ] </symbol>\n"

					# If symbolTable contains varName symbol --> do:
					if self.symbolTable.ContainsSymbol(varName):
						segment, index = self.symbolTable.SegmentIndexOf(varName)
						output += self.vmWriter.writePush(segment, index) 
						output += self.vmWriter.writeArithmetic(ARITHMETIC_ADD)
						output += self.vmWriter.writePop("pointer", 1)
						output += self.vmWriter.writePush("that", 0)

			# Variable:
			else:
				segment, index = self.symbolTable.SegmentIndexOf(varName)
				output += self.vmWriter.writePush(segment, index) 

		# Symbol --> ( --> Parentheses expression:
		elif self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == "(":
			# output += indent + "  " + "<symbol> ( </symbol>\n"

			# Advance:
			self.jackTokenizer.advance()

			output += self.CompileExpression(indent + "  ")

			# Symbol --> ):
			if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ")":
				# output += indent + "  " + "<symbol> ) </symbol>\n"

				# Pass:
				pass

		# Error:
		else:
			print("Error compiling the tokens! Program will abort.")
			sys.exit()

		# Advance:
		self.jackTokenizer.advance()

		# output += indent + "</term>\n"

		# Return:
		return output


	# Compilation --> Comma-Separated List of Expression(s):
	def CompileExpressionList(self, indent):

		# Local Variable Declaration and Initialization:
		# output = indent + "<expressionList>\n"
		output = ""
		nArgs = 0

		# Symbol --> ):
		if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ")":
			# output += indent + "</expressionList>\n"

			# Return:
			return output, nArgs

		else:
			while True:
				output += self.CompileExpression(indent + "  ")
				nArgs += 1

				# Symbol --> ):
				if self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ")":
					# output += indent + "</expressionList>\n"

					# Return:
					return output, nArgs

				# Symbol --> ,:
				elif self.jackTokenizer.tokenType() == TOKENTYPE_SYMBOL and self.jackTokenizer.symbol() == ",":
					# output += indent + "  " + "<symbol> , </symbol>\n"

					# Advance:
					self.jackTokenizer.advance()

					# Continue:
					continue

				# Error:
				else:
					print("Error compiling the tokens! Program will abort.")
					sys.exit()