Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 05
File Name: README.txt

1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
Memory.hdl and Computer.hdl were not too terribly difficult to tackle, although I ran into a lot of unexpected issues understanding the material to begin with.  The textbook was good about displaying pictures of how it should be laid out which was helpful in understanding the material at hand better.  

2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
The overall designing of the CPU.hdl was horrible to try to implement.  I found the picture in the book to be very helpful in determining how to make the initial design but found figuring out the control bits to the multiplexors as well as conditional jumps to be a major pain.  It took me almost a whole day working diligently on this one to figure it all out.  

3. Estimate how long you worked on the project.
-----------------------------------------------
Reading Chapter # 5 took approximately 2 hours.
Memory.hdl took approximately 3 hours.
CPU.hdl took approximately 10 hours.
Computer.hdl took approximately 3 hours.
README.txt took approximately .5 hour.