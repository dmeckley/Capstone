Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 00
File Name: README.txt

1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
Installing the nand2tetris software platform was fairly simple.  At least for Windows it was.  I am still trying to figure out how to install it to the Ubunta Virtual Machine though. The user interface seems pretty simple for the Hardware Simulator but I am still in the process of learning the details around it.

2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
I didn't really understand the programming architecture of it very much yet but I guess 
maybe that will come in time?  I utilized the demo chip to simulate operation of the 
Hardware Simulator and to familiarize myself with the platform but I am not really sure 
where the x and y are actually coming from?  Again, probably something that I will learn
more about as we travel this road. 

Also, I was not sure if we were suppose to upload the file.txt file to the Coursera website or if we were just suppose to drop this into the google drive for the ciss494 course either?  Therefore, in addition to attaching this file to the ciss494 google
drive, I am also attaching the file.txt file per project # 00 instructions at the following link: http://www.nand2tetris.org/00.php
I will not upload to the Coursera website unless specified otherwise.   

3. Estimate how long you worked on the project.
-----------------------------------------------
Approximately 1 hour to read directions and to install the nand2tetris software plateform
In addition, about another hour playing with the platform itself on Windows and trying to install the nand2tetris software platform on the Ubunta Virtual Machine which has not been a success yet.  Maybe 30 minutes reading the introduction chapter?  