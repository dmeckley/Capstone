Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 04
File Name: README.txt

1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
I found the Mult.asm to be fairly easy and straight forward since I had build this program before in the ciss360 course utilizing the x86 framework for assembly programming; therefore, I just had to take some time to find the source file which I saved from my previous course and learn how to manipulate the Hack assembly language to make it work accordingly to my previous x86 souce code. 

2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
I thought that the whole Fill.asm project was very confusing myself.  It took me a long time to reach to a workable solution for the problem.  I think maybe some of it is because I am not all that proficient with graphic type programming anyway due to a limited exposure to it.  Learning how to utilized the Assembler and CPU Emulator together was also a major pain with the Fill.asm part of the project.  I never really had to utilize the Assembler much with the Mult.asm part of the project, instead I only had to utilize the CPU Emulator.

3. Estimate how long you worked on the project.
-----------------------------------------------
Mult.asm took me approximately 3 hours to complete.
Fill.asm took me approximately 6 hours to complete.