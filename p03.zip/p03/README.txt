Name: Dustin Meckley
Course: ciss494 Senior Seminar in Computer Science
Professor: Dr. Seth Warn
Project: # 03
File Name: README.txt

1. Describe something that was interesting, fun, or easy about the project.
---------------------------------------------------------------------------
I found the Bit and Register to be fairly simple to implement.  I actually found the bit itself to be harder than that of the Register.  I would say the fun part for me was getting a better idea as to how the individual pieces actually work and the working details of them, especially when it came to the RAM chips.  Having designed the program counter in logisim in ciss420 Computer Architecture made it easier to tackle the program counter in the hdl.  

2. Describe something that was difficult, confusing, or time-consuming about the project.
-----------------------------------------------------------------------------------------
I really still don't understand as to why the PC has to be sequenced in the order of increment, load, reset instead of reset, load, increment like how the if-elseif-else logic states at the top of the PC.hdl skeleton source code?  However, I did finally get it to work this way simply out of pure luck.  In addition to finding the PC to be very difficult to figure out, I also found the RAM chips to be especially difficult to intitially figure out.  But once I got the first two done: the RAM8 and RAM64, I found the rest of them to be more of a copy and paste operation with a little note taking and drawing of pictures in order to have it all laid out in my mind. 

3. Estimate how long you worked on the project.
-----------------------------------------------
Bit.hdl, Register.hdl took approximately two hours to complete.
The RAM chips took approximately ten hours to complete.
The Program Counter and README took approximately four hours to complete.